'use strict';
const { load } = require('./config');
const { open } = require('./db');
const { createProvider } = require('./ai/providers');
const { createApp } = require('./server');

const cfg = load();
const db = open(cfg.dbPath);
const app = createApp({ db, cfg, provider: createProvider(cfg) });
app.listen(cfg.port, () => console.log(`BELNOVA backend on :${cfg.port} (db: ${cfg.dbPath}, AI: ${cfg.aiEnabled ? cfg.aiProvider : 'off'})`));
