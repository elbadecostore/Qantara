'use strict';
// Express layer. Thin: security decisions live in guards.js, business rules in services/accounts/assistant.
const fs = require('fs');
const path = require('path');
const svc = require('./services');
const accounts = require('./accounts');
const assistant = require('./ai/assistant');
const budget = require('./ai/budget');
const guards = require('./guards');
const { RateLimiter, SqliteStore } = require('./rateLimit');
const { createMailer } = require('./mailer');

const COOKIE = 'belnova_session';
const MIN = 60 * 1000;

function createApp({ db, cfg, provider, mailer = createMailer(cfg) }) {
  const express = require('express'); // Installed by `npm install`; unit tests do not need it.
  const app = express();
  const limiter = new RateLimiter(new SqliteStore(db)); // shared across processes sharing the DB file
  app.disable('x-powered-by');
  app.set('trust proxy', cfg.trustProxy);
  app.use(express.json({ limit: '16kb' }));
  app.use((_req, res, next) => {
    res.set({
      'X-Content-Type-Options': 'nosniff',
      'Referrer-Policy': 'no-referrer',
      'Cross-Origin-Resource-Policy': 'same-origin',
    });
    next();
  });

  // CSRF defence: every state-changing request must carry an allow-listed Origin.
  app.use('/api', (req, res, next) => {
    const r = guards.checkOrigin(req.method, req.get('origin'), cfg.allowedOrigins);
    if (!r.ok) return res.status(403).json({ error: r.code });
    next();
  });

  app.use((req, _res, next) => {
    req.cookies = guards.parseCookies(req.headers.cookie);
    req.user = svc.userFromSession(db, req.cookies[COOKIE]);
    next();
  });

  const wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
  const rate = (name, max, windowMs, keyOf = (req) => (req.user ? 'u' + req.user.id : 'ip' + req.ip)) =>
    wrap(async (req, res, next) => {
      const r = await limiter.hit(`${name}:${keyOf(req)}`, max, windowMs);
      if (!r.ok) { res.set('Retry-After', String(r.retryAfter)); return res.status(429).json({ error: 'rate_limited' }); }
      next();
    });
  const need = (...roles) => (req, res, next) => {
    if (!req.user) return res.status(401).json({ error: 'login_required' });
    if (roles.length && !roles.includes(req.user.role)) return res.status(403).json({ error: 'forbidden' });
    next();
  };
  const cookieOpts = { httpOnly: true, sameSite: 'lax', secure: cfg.cookieSecure, path: '/' };
  const startSession = (res, userId) => {
    const s = svc.createSession(db, userId);
    res.cookie(COOKIE, s.token, { ...cookieOpts, maxAge: 14 * 24 * 60 * MIN });
  };
  const emailKey = (req) => 'e' + String(req.body?.email || '').trim().toLowerCase();

  app.get('/api/health', (_req, res) => res.json({ ok: true, aiConfigured: Boolean(provider && provider.configured()) }));

  // ----- accounts -----
  app.post('/api/auth/register', rate('register', 5, 15 * MIN, (req) => 'ip' + req.ip), wrap(async (req, res) => {
    const user = svc.createUser(db, req.body?.email, req.body?.password);
    startSession(res, user.id);
    try { await accounts.sendVerificationEmail(db, mailer, cfg, user); } catch { /* user can request again */ }
    res.status(201).json({ user: { id: user.id, email: user.email, role: user.role, emailVerified: false } });
  }));
  app.post('/api/auth/login', rate('login-ip', 20, 15 * MIN, (req) => 'ip' + req.ip), rate('login-email', 10, 15 * MIN, emailKey), wrap((req, res) => {
    const user = svc.authenticate(db, req.body?.email, req.body?.password);
    if (!user) return res.status(401).json({ error: 'invalid_credentials' });
    startSession(res, user.id);
    res.json({ user });
  }));
  app.post('/api/auth/logout', wrap((req, res) => {
    svc.destroySession(db, req.cookies[COOKIE]);
    res.clearCookie(COOKIE, cookieOpts).json({ ok: true });
  }));
  app.get('/api/me', (req, res) => res.json({ user: req.user || null }));

  app.post('/api/auth/verify-email/request', need(), rate('verify-req', 3, 60 * MIN), wrap(async (req, res) => {
    await accounts.sendVerificationEmail(db, mailer, cfg, { id: req.user.id, email: req.user.email });
    res.json({ ok: true });
  }));
  app.post('/api/auth/verify-email/confirm', rate('verify-confirm', 20, 15 * MIN, (req) => 'ip' + req.ip), wrap((req, res) => {
    accounts.confirmEmail(db, req.body?.token);
    res.json({ ok: true });
  }));
  app.post('/api/auth/password-reset/request', rate('reset-req', 5, 60 * MIN, (req) => 'ip' + req.ip), rate('reset-req-email', 3, 60 * MIN, emailKey), wrap(async (req, res) => {
    res.json(await accounts.requestPasswordReset(db, mailer, cfg, req.body?.email));
  }));
  app.post('/api/auth/password-reset/confirm', rate('reset-confirm', 10, 15 * MIN, (req) => 'ip' + req.ip), wrap((req, res) => {
    accounts.resetPassword(db, req.body?.token, req.body?.password);
    res.clearCookie(COOKIE, cookieOpts).json({ ok: true });
  }));
  app.post('/api/auth/change-password', need(), rate('change-pw', 5, 15 * MIN), wrap((req, res) => {
    accounts.changePassword(db, req.user.id, req.body?.current, req.body?.password);
    startSession(res, req.user.id);
    res.json({ ok: true });
  }));
  app.delete('/api/account', need(), rate('delete-account', 3, 60 * MIN), wrap((req, res) => {
    accounts.deleteAccount(db, req.user.id, req.body?.password);
    res.clearCookie(COOKIE, cookieOpts).json({ ok: true });
  }));

  // ----- public browsing (no account needed) -----
  app.get('/api/directory', wrap((req, res) => res.json({ items: svc.listDirectory(db, req.query) })));
  app.get('/api/listings', wrap((req, res) => res.json({ items: svc.searchListings(db, req.query) })));
  app.post('/api/listings/:id/report', rate('report', 5, 60 * MIN), wrap((req, res) => {
    const id = svc.reportListing(db, req.user ? req.user.id : null, req.params.id, req.body?.reason);
    res.status(201).json({ id });
  }));

  // ----- member features -----
  app.post('/api/listings', need(), rate('submit', 10, 60 * MIN), wrap((req, res) => {
    const id = svc.submitListing(db, req.user, req.body || {});
    res.status(201).json({ id, status: 'pending' });
  }));
  app.get('/api/profile', need(), wrap((req, res) => res.json({ profile: svc.getProfile(db, req.user.id) })));
  app.put('/api/profile', need(), wrap((req, res) => res.json({ profile: svc.saveProfile(db, req.user.id, req.body || {}) })));
  app.delete('/api/profile', need(), wrap((req, res) => { svc.deleteUserData(db, req.user.id); res.json({ ok: true }); }));
  app.get('/api/saved', need(), wrap((req, res) => res.json({ items: svc.listSaved(db, req.user.id) })));
  app.post('/api/saved', need(), wrap((req, res) => {
    svc.saveItem(db, req.user.id, req.body?.type, req.body?.id);
    res.status(201).json({ ok: true });
  }));
  app.delete('/api/saved/:type/:id', need(), wrap((req, res) => {
    svc.removeItem(db, req.user.id, req.params.type, req.params.id);
    res.json({ ok: true });
  }));

  // ----- BELNOVA AI (anonymous allowed, stricter limit per IP) -----
  app.post('/api/ai/chat', rate('ai', 30, 60 * MIN), wrap(async (req, res) => {
    const out = await assistant.answer({
      db, cfg, provider, user: req.user || null,
      conversationToken: req.body?.conversationToken, message: req.body?.message,
    });
    res.json(out);
  }));

  // ----- moderation and administration -----
  app.get('/api/admin/listings', need('moderator', 'admin'), wrap((req, res) => res.json({ items: svc.listByStatus(db, req.user, String(req.query.status || 'pending')) })));
  app.post('/api/admin/listings/:id/decision', need('moderator', 'admin'), wrap((req, res) => {
    svc.moderateListing(db, req.user, req.params.id, req.body || {});
    res.json({ ok: true });
  }));
  app.get('/api/admin/reports', need('moderator', 'admin'), wrap((req, res) => res.json({ items: svc.listReports(db, req.user, String(req.query.status || 'open')) })));
  app.post('/api/admin/reports/:id/resolve', need('moderator', 'admin'), wrap((req, res) => {
    svc.resolveReport(db, req.user, req.params.id, req.body || {});
    res.json({ ok: true });
  }));
  app.put('/api/admin/sources', need('admin'), wrap((req, res) => res.status(201).json({ id: svc.upsertSource(db, req.user.id, req.body || {}) })));
  app.get('/api/admin/ai-usage', need('admin'), wrap((_req, res) => res.json(budget.monthlyReport(db, cfg))));

  // ----- errors -----
  app.use((err, _req, res, _next) => {
    if (err instanceof svc.AppError) return res.status(err.status).json({ error: err.code });
    if (err.type === 'entity.parse.failed') return res.status(400).json({ error: 'invalid_json' });
    if (err.type === 'entity.too.large') return res.status(413).json({ error: 'payload_too_large' });
    if (err.code === 'mail_not_configured') return res.status(503).json({ error: 'mail_not_configured' });
    console.error(err);
    res.status(500).json({ error: 'internal' });
  });

  const publicDir = path.join(__dirname, '..', 'public');
  if (fs.existsSync(publicDir)) app.use(express.static(publicDir));
  return app;
}

module.exports = { createApp };
