'use strict';
// Usage: node scripts/seed-sources.js   (idempotent: updates existing rows by slug)
const { open } = require('../src/db');
const { upsertSource } = require('../src/services');
const { load } = require('../src/config');
const seed = require('../src/seed-data');
const db = open(load().dbPath);
for (const s of seed) upsertSource(db, null, { ...s, permission_status: 'none', access_method: 'none', terms_checked_at: null });
console.log(`seeded ${seed.length} official reference sites`);
