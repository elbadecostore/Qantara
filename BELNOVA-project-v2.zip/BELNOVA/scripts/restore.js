'use strict';
// Usage: node scripts/restore.js <backup-file> [--force]
// Stop the server first (systemctl stop belnova). The script refuses to overwrite without --force.
const { load } = require('../src/config');
const { restore } = require('../src/backup');
const [file, flag] = process.argv.slice(2);
if (!file) { console.error('usage: node scripts/restore.js <backup-file> [--force]'); process.exit(1); }
const result = restore(file, load().dbPath, { force: flag === '--force' });
console.log('restored and verified; migrations version:', result.migrations);
