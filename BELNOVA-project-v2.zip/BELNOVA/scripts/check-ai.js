'use strict';
// Usage: npm run check-ai -- "I need work in Brussels"
// Runs the same path as the website (config -> provider -> spending guard -> database -> answer) without HTTP.
const { load } = require('../src/config');
const { open } = require('../src/db');
const { createProvider } = require('../src/ai/providers');
const { aiStatus } = require('../src/ai/status');
const assistant = require('../src/ai/assistant');

(async () => {
  const cfg = load();
  const provider = createProvider(cfg);
  const status = aiStatus(cfg, provider);
  console.log('AI status:', JSON.stringify(status));
  if (!status.ready) { console.log('NOT READY. Fix the reason above in .env, then run again.'); process.exit(2); }
  const db = open(cfg.dbPath);
  const out = await assistant.answer({ db, cfg, provider, message: process.argv[2] || 'I need work in Brussels' });
  console.log('status:', out.status, out.code || '');
  console.log('reply :', out.reply);
  console.log('items :', out.items.map((i) => `${i.type}:${i.name}`).join(' | ') || '(none)');
  process.exit(out.status === 'ok' ? 0 : 1);
})();
