'use strict';
// Usage: ADMIN_EMAIL=you@example.org ADMIN_PASSWORD='long passphrase' node scripts/bootstrap-admin.js
// The password is read from the environment, never from the command line (shell history leaks it).
const { open } = require('../src/db');
const { createUser, audit } = require('../src/services');
const { load } = require('../src/config');
const db = open(load().dbPath);
const email = process.env.ADMIN_EMAIL, password = process.env.ADMIN_PASSWORD;
if (!email || !password) { console.error('Set ADMIN_EMAIL and ADMIN_PASSWORD'); process.exit(1); }
let user;
try { user = createUser(db, email, password); } catch (e) {
  if (e.code !== 'email_taken') throw e;
  user = db.prepare('SELECT id, email FROM users WHERE email = ?').get(email.toLowerCase());
}
db.prepare("UPDATE users SET role = 'admin' WHERE id = ?").run(user.id);
audit(db, user.id, 'user.promoted_admin', `user:${user.id}`);
console.log(`admin ready: ${email}`);
