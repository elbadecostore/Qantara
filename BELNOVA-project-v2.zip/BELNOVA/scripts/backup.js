'use strict';
// Usage: node scripts/backup.js [destination-file]   (default: ./backups/belnova-<timestamp>.sqlite)
const path = require('path');
const { open } = require('../src/db');
const { load } = require('../src/config');
const { backup } = require('../src/backup');
const cfg = load();
const db = open(cfg.dbPath);
const stamp = new Date().toISOString().replace(/[:.]/g, '-');
const dest = process.argv[2] || path.join('backups', `belnova-${stamp}.sqlite`);
console.log('backup written and verified:', backup(db, dest));
