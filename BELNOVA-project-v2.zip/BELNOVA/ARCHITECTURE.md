# BELNOVA — Architecture (stage 2: website connected to the backend)

## 1. Stack
| Layer | Choice | Notes |
|---|---|---|
| Frontend | Existing single-file HTML/JS, served from `public/` | Connected to the API in stage 2 |
| Backend | Node.js **22.23.5** (pinned in `.nvmrc`, `engines >=22.13 <23`), Express 4 | Tested on 22.23.5 only |
| Database | SQLite through built-in `node:sqlite` (experimental in Node 22; the start script hides its warning) | Migrations in `db/migrations/`, applied in order |
| Auth | Email + password, scrypt, random session tokens (only SHA-256 hash stored), HttpOnly SameSite=Lax cookies, roles user / moderator / admin | |
| AI | Server-side only, provider adapter (`src/ai/providers.js`), **disabled by default** | Provider switch = one adapter function |
| Mail | Adapter (`src/mailer.js`): `none` (production default, fails visibly), `console` (dev), `memory` (tests) | No provider chosen yet |
| Hosting | Any VPS behind Caddy/Nginx (HTTPS) | Nothing purchased |

## 2. Structure
```
db/migrations/001_init.sql      core schema
db/migrations/002_security.sql  email verification, reset tokens, conversation tokens, shared rate limits
src/
  index.js        entry point                 config.js     env + safe defaults
  db.js           open + migrate              security.js   scrypt, tokens, hashes
  guards.js       CSRF origin check, cookies  rateLimit.js  memory and SQLite stores
  services.js     accounts/profiles/directory/listings/moderation rules (role checks inside)
  accounts.js     verify email, reset, change password, delete account
  backup.js       VACUUM INTO backup, integrity-checked restore
  mailer.js       mail adapter                server.js     Express routes (thin)
  categories.js   categories + multilingual keywords
  seed-data.js    official reference sites (links, not listings)
  ai/assistant.js BELNOVA AI: DB retrieval, prompt, conversation memory
  ai/budget.js    spending guard              ai/providers.js provider adapters
scripts/          seed, bootstrap-admin, backup, restore
test/             unit.test.js, security.test.js, backup.test.js, server.test.js
```

## 3. Database (summary)
- `users`: email (unique, case-insensitive), scrypt hash, role, disabled, `email_verified_at`.
- `sessions`: token hash, user, expiry. `auth_tokens`: purpose (`verify_email` / `reset_password`), token hash, expiry, `used_at`.
- `profiles`: exists only after consent (`consent_at` required). `saved_items`, `reports`, `messages` (schema only; routes come later).
- `ai_conversations`: `token_hash` (unique index). Messages in `ai_messages`. `ai_usage`: cost ledger.
- `sources` + `source_categories`: official reference sites. Automated import needs `permission_status = granted`, enforced in code and tested.
- `listings`: `status` (pending / approved / rejected / expired / reported), `verification` (none / source_link_checked / verified). Approval is not verification.
- `rate_limits`: shared counters. `audit_log`: moderation and admin actions.
- Constraints (enums, https-only URLs, length limits, ranges) are in the database, not only in code.

## 4. Security controls
**CSRF.** Every state-changing request under `/api` (POST, PUT, PATCH, DELETE) must carry an `Origin` header that is on the allow-list (`APP_URL` plus `APP_ORIGINS`). Missing or foreign origins are refused with `origin_required` or `origin_not_allowed`. This is the primary control. SameSite=Lax cookies and JSON bodies are added on top.

**Passwords.** scrypt (N=16384, r=8, p=1), constant-time comparison, dummy hash for unknown emails. Minimum 12 characters.

**Sessions.** 32-byte random tokens, stored as SHA-256 hashes only. Cookie: HttpOnly, SameSite=Lax, Secure in production, 14 days. Ended by logout, password reset, password change (all other sessions), account deletion, or account disabling.

**Account recovery (ready, mailer not yet configured).**
- Email verification: link with a 48-hour, single-use token sent after registration. Resend limited to 3 per hour.
- Password reset: `POST /api/auth/password-reset/request` always answers `{ok:true}`, so it cannot be used to find accounts. The token travels in the URL fragment (`#token=`), which browsers do not send to the server in logs. Tokens last 60 minutes and are single-use. Requesting a new one invalidates the old one. A successful reset also revokes all sessions and marks the email as verified.
- Mail failures are logged as `password_reset.mail_failed` without the token. Until a provider is configured, these flows cannot be completed by email (the API returns `mail_not_configured` where a mail is required).

**Rate limits.** Fixed window, stored in `rate_limits` (SQLite) through a store interface. Two app processes sharing the database share the counters (tested). Moving to Redis means writing one more store class. Current limits: register 5/15 min per IP, login 20/15 min per IP and 10/15 min per email, reset request 5/h per IP and 3/h per email, report 5/h, submit 10/h, AI chat 30/h, account deletion 3/h.

**Input.** Body limit 16 KB. Text is trimmed and stripped of control characters, length-capped and parameterised. LIKE wildcards are escaped. URLs must be https. Years 0 to 60, budget 0 to 100000, employment f/p/a. Stored text is plain text; the frontend escapes on output.

**Authorisation.** Roles are checked in the routes and again in the services (`assertRole`), so a direct service call cannot bypass them. Only a trusted local script (`actor === null`) can administer sources.

**Privacy and deletion.** `DELETE /api/account` requires the current password. It removes, in one transaction: the user row (cascading sessions, reset tokens, messages), profile, saved items, AI conversations and their messages, and the user's own community listings (with their reports and other users' saved pointers to them). Anonymised: the audit trail actor, reports and moderation attributions (set to null), and the AI cost ledger (keeps amounts, loses the user). `DELETE /api/profile` removes only profile, saved items and AI conversations, and keeps the account.
*Product decision to confirm:* deleting an account removes the community listings that person submitted. The alternative is to keep approved ones anonymised.

**Anonymous conversations.** BELNOVA AI creates a conversation with a random 32-byte token. Only its hash is stored. Anonymous conversations can be read only by a request that presents the token. Signed-in users' conversations are readable only by their owner. Numeric ids are never returned or accepted. A wrong or missing token returns 404. Losing the token means losing that conversation (it is not recoverable by BELNOVA by design).

**Headers.** `X-Content-Type-Options: nosniff`, `Referrer-Policy: no-referrer`, `Cross-Origin-Resource-Policy: same-origin`, `X-Powered-By` disabled.

## 5. Backups and restore (tested)
- Backup: `npm run backup` (or `node scripts/backup.js [file]`). Uses `VACUUM INTO`, which writes a consistent copy while the app runs. It does not need the `sqlite3` command-line tool, which is **not installed** on the build machine. Each backup is checked with `PRAGMA integrity_check` and must contain the BELNOVA schema.
- Restore: stop the service first, then `node scripts/restore.js <file>`. It refuses to overwrite an existing database without `--force`, removes stale `-wal` and `-shm` files, and verifies the restored copy.
- Tested: a database with sources, a user, a profile and an approved listing is backed up, restored to another path, and compared row by row. Login and search work afterwards. Corrupt and foreign files are refused.
- Recommended schedule (cron on the VPS): daily `npm run backup`, copy off the server, keep 14 days, and run a restore test each month.

## 6. BELNOVA AI and spending guard
- Answers come only from the database catalogue (official sites and approved listings). The system prompt forbids invented jobs, prices, eligibility and partnerships.
- Calls happen only when all of these pass: `AI_ENABLED=true`, provider key and model set, both token prices set and above 0, monthly cap above 0 that the reserved cost of this call keeps under, global daily count below `AI_DAILY_LIMIT_GLOBAL`, per-user daily count below `AI_DAILY_LIMIT_PER_USER`. Otherwise the reply is `status: "unavailable"` with a code (`ai_disabled`, `ai_not_configured`, `ai_prices_not_set`, `ai_limit_not_set`, `ai_monthly_limit`, `ai_daily_limit`, `ai_user_daily_limit`, `ai_provider_error`).
- Output is capped at `AI_MAX_OUTPUT_TOKENS`. Every call's real cost is recorded. `GET /api/admin/ai-usage` shows spend and call counts for the admin.
- The mock provider in the tests is the only provider run so far.

**Getting and configuring a provider key securely (you do this yourself):**
1. Create the account in the provider's console. Never share the key or paste it in chat or code.
2. In the console, set a monthly spending limit and alerts. This is a second safety net outside BELNOVA.
3. Create a key named `belnova-prod` and copy it once.
4. On the VPS, put it only in `/etc/belnova.env` (owner `belnova`, mode `600`). Never in the repository, the HTML, or logs.
5. Set `AI_MODEL` to the exact model id from the provider's current documentation and the two token prices from its price page. Then set `AI_MONTHLY_LIMIT_EUR`, and only then `AI_ENABLED=true`.
6. If a key is exposed, revoke it in the console, create a new one, update the file and restart.

## 7. Sources: integration path
Stage 1 stores official reference sites only. A future integration goes through `PUT /api/admin/sources` with `access_method` `api`, `rss` or `partnership` and `permission_status = granted`. Without that, the database refuses it. Imported items will enter as `pending` external listings. Link checks will set `source_link_checked` only after fetching the listing itself, and only a human sets `verified`.

## 8. Deployment outline
1. Install Node 22.23.5 (`nvm use` reads `.nvmrc`). Create user `belnova`.
2. Copy the project to `/srv/belnova`, run `npm ci --omit=dev`.
3. Create `/etc/belnova.env` from `.env.example` (mode 600). Set `NODE_ENV=production`, `APP_URL=https://<your domain>`, `TRUST_PROXY=true`, `MAIL_PROVIDER` (once chosen).
4. `npm run seed`. Create the admin with `ADMIN_EMAIL=... ADMIN_PASSWORD=... npm run admin`, using the environment, not a command-line argument.
5. systemd unit: `EnvironmentFile=/etc/belnova.env`, `User=belnova`, `ExecStart=/usr/bin/node --disable-warning=ExperimentalWarning src/index.js`, `Restart=always`.
6. Caddy or Nginx in front for HTTPS. Open only ports 80, 443 and SSH.
7. Backups as in section 5.

## 9. Testing: what was actually run
Command: `npm test` (Node 22.23.5, sandbox, no network).

| Suite | Result | What it covers |
|---|---|---|
| `unit.test.js` (25) | **all pass** | schema constraints, migrations, passwords, sessions, consent, directory permission rule, moderation, reports, saved items, AI spending guard, assistant retrieval and memory, provider failure, rate limiter |
| `security.test.js` (23) | **all pass** | CSRF origin rules, origin normalisation, cookie parsing, shared rate limit across two instances, reset and verification flows and token rules, session revocation, password change, privilege escalation (services), input validation, control-character stripping, deletion scope, anonymous conversation tokens |
| `backup.test.js` (3) | **all pass** | backup, integrity check, restore with data comparison and working login, refusal rules |
| `server.test.js` (1) | **not executed** | Full HTTP flow: Origin enforcement on real requests, cookies, reset, deletion. Needs `npm install` (Express). The sandbox could not reach the npm registry. |

Totals in the sandbox: **52 tests, 51 passed, 0 failed, 1 skipped** (the HTTP test).

**Not tested yet:** the real AI provider (no key, no network); real email delivery (no provider chosen); the frontend (stage 2); behaviour under load; running on the actual VPS.

## 10. Open decisions for you
1. Approve the account-deletion scope in section 4 (community listings removed with the account).
2. Choose the mail provider (for verification and password reset) when you are ready.
3. Confirm the monthly AI budget before enabling AI.
4. Run `npm install && npm test` on your machine to execute the HTTP test.
5. Approve moving to stage 2 (connecting the frontend to these APIs).


## 11. Stage 2 (website connected to the backend)

**What the website now does through the API (no sample data):**
- Account: register, sign in, sign out (`/api/auth/*`, `/api/me`).
- Browsing and search of the official directory and of approved community listings. No account is needed.
- Community listing submission (signed-in only). It stays `pending` until a moderator approves it.
- Reporting a listing (anyone). A report hides the listing until a moderator decides.
- Saved items (signed-in only), shown with their names on the profile page.
- Profile with consent (save, edit, delete) and account deletion with password confirmation.
- BELNOVA AI through `/api/ai/chat`. Replies and the items shown come only from the database. The conversation token is kept in page memory, not in browser storage.
- Loading states, and error messages translated into all eight languages from server error codes.

**Security of the page:** the page contains no keys and no sample listings. Data fields are escaped before being inserted, and links are shown only when they start with `https://`. Auth tokens are never stored in browser storage: the session is an HttpOnly cookie.

**Opt-in anonymous retention (prepared, not offered in the page yet):** `deleteAccount(db, userId, password, { keepContributionsAnonymously: true })` keeps only approved submissions, removes e-mail addresses, phone numbers and personal social links from them, and detaches them from the account. Pending and rejected submissions are still deleted. The page must present this as an explicit, separate choice before a future release.

**Mail (Brevo), prepared and inert:**
- The adapter is in `src/mailer.js`. It sends nothing unless `MAIL_SEND_ENABLED=true`, a `BREVO_API_KEY` is set, and `MAIL_FROM` is a verified sender. The tests confirm that with the flag off no network call is made.
- Registration sends a verification e-mail, and the reset page sends a link. Both are silent when mail is off, so the site works without them.
- **Not tested against the real service.** The request format follows Brevo's transactional e-mail endpoint (`POST https://api.brevo.com/v3/smtp/email`, header `api-key`). It is checked against a stubbed transport only.

**How to link Brevo later (not done; needs your approval):**
1. Create a Brevo account yourself and choose the free plan if it fits your volume. Do not add a payment method unless you decide to.
2. In Brevo, add and verify the sender address you will use (`MAIL_FROM`). Verification means confirming the address by e-mail.
3. Create an API key with a name such as `belnova-prod`, and copy it once.
4. On the server only, set `BREVO_API_KEY`, `MAIL_FROM`, `MAIL_PROVIDER=brevo`. Keep `MAIL_SEND_ENABLED=false` for the first check.
5. Send yourself a single test message through the reset flow, then set `MAIL_SEND_ENABLED=true` once you approve.

**AI provider:** the page uses `AI_PROVIDER=mock` for free testing. `anthropic` stays disabled (`AI_ENABLED=false`) and requires the key steps in section 6 and your approval.

**Test status for stage 2:**
| Check | Status |
|---|---|
| Page script runs against a stubbed DOM and API: save requires sign-in, hostile titles escaped, unsafe links refused, assistant shows only server data, token handling, error translation, all eight languages render without raw keys | **Run and passed** (10 tests, `test/frontend.test.js`) |
| Page contains no secrets and no sample listings; every page API call matches a server route; every translation key has eight entries; every used key exists | **Run and passed** |
| Opt-in retention scrubbing and rules; saved items with names; free AI provider with zero cost; paid provider blocked without prices; Brevo inert by default and correct payload when enabled (stubbed) | **Run and passed** (9 tests, `test/phase2.test.js`) |
| Full HTTP flows: browse without account, submit, moderate, report, save, free AI, delete, cookies | **Written, NOT executed.** Needs Express. Run `npm install && npm test`. |
| The page running in a real browser, layout on phones and desktops | **Not tested** (no browser in the build sandbox) |
| Brevo real delivery | **Not tested** (no approval, no account) |
| Paid AI | **Not tested** (not enabled) |

Totals in the build sandbox: 72 tests: 70 passed, 0 failed, 2 skipped (both HTTP).
