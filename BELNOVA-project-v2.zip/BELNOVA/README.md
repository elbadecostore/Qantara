# BELNOVA (backend + website, stage 2)

Node 22.23.5 (`.nvmrc`), Express 4, SQLite via `node:sqlite`. The website is served from `public/`.
Full design: `ARCHITECTURE.md`.

## Run the tests (step by step)
1. Install Node 22.23.5: `nvm install 22.23.5 && nvm use` (or use the version in `.nvmrc`).
2. In the project folder: `npm install`
3. `npm test`
   - Expected: about 70 passing tests and 2 skipped.
   - The 2 skipped tests are the HTTP tests in `test/server.test.js`. They run automatically once `npm install` has installed Express. If they fail, the output names the exact check.
4. To run one file: `node --test test/frontend.test.js`

## Run the site locally with free test AI
```
cp .env.example .env     # set APP_URL=http://localhost:3000, AI_ENABLED=true, AI_PROVIDER=mock
npm run seed             # official reference sites (links only)
npm start                # open http://localhost:3000
```
Mail stays off. Password reset and email verification are created but not sent.

## Other commands
```
ADMIN_EMAIL=you@example.org ADMIN_PASSWORD='...' npm run admin
npm run backup
node scripts/restore.js backups/<file>.sqlite     # stop the server first
```
