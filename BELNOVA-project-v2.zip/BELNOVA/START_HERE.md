# BELNOVA — ابدأ من هنا (بالعربية)

هذا المجلد يحتوي على الموقع (`public/`) والخادم (`src/`) وقاعدة البيانات (`db/`) والاختبارات (`test/`).

## 1. المتطلبات
- Node.js بالإصدار **22.23.5** بالضبط (الرقم موجود في ملف `.nvmrc`). تحميله من nodejs.org، أو عبر nvm:
  - Windows: `nvm install 22.23.5` ثم `nvm use 22.23.5`
  - macOS/Linux: `nvm install 22.23.5` ثم `nvm use 22.23.5`
- التحقق: `node -v` يجب أن يعرض `v22.23.5`.

## 2. التثبيت
افتح الطرفية داخل مجلد `BELNOVA` ونفّذ:
```
npm install
```
سيُنشئ هذا الأمر ملف `package-lock.json`. احتفظ به؛ هو يثبّت نفس الإصدارات في كل مرة.

## 3. الاختبار
```
npm test
```
- الناتج المتوقع: 72 اختباراً، تنجح كلها.
- اختبارات HTTP (في `test/server.test.js`) تعمل بعد `npm install` فقط، لأنها تحتاج Express.
- إذا فشل اختبار، سيذكر الناتج اسمه بالضبط. أرسل النص لمراجعته.

## 4. الإعداد (مهم لتفعيل NOVA)
انسخ ملف الإعداد داخل مجلد `BELNOVA` نفسه (بجوار `package.json`):
- Windows: `copy .env.example .env`
- macOS/Linux: `cp .env.example .env`

افتح `.env` وغيّر هذه السطور فقط (للتجربة المحلية، مجانية ولا تحتاج مفتاحاً):
```
APP_URL=http://localhost:3000
COOKIE_SECURE=false
AI_ENABLED=true
AI_PROVIDER=mock
```
- `AI_PROVIDER=mock` مزود تجريبي مجاني: لا يستخدم أي نموذج ذكاء اصطناعي ولا يكلّف شيئاً، ويقول بوضوح إنه وضع اختبار.
- لا تضع أي مفتاح سري في `.env` لهذه التجربة.
- البريد الإلكتروني يبقى معطّلاً ولن يُرسل أي رسالة.

## 5. تحميل المصادر الرسمية (روابط فقط، ليست إعلانات)
```
npm run seed
```

## 5b. فحص NOVA قبل تشغيل الموقع
```
npm run check-ai -- "I need work in Brussels"
```
- يجب أن ترى: `AI status: ... "ready":true` و`status: ok` وردّاً وقائمة عناصر.
- إذا رأيت `NOT READY` فالسطر نفسه يذكر السبب، مثل `ai_disabled`، وهو يعني أن `AI_ENABLED` ليس `true` في `.env`.

## 6. تشغيل الموقع
```
npm start
```
يجب أن ترى في الطرفية السطر: `BELNOVA AI: ready (mock, free test provider)`.
إذا رأيت `NOT ready, reason: ...` فالسبب مكتوب في السطر.
ثم افتح المتصفح على: **http://localhost:3000**
وافتح مساعد NOVA من الزر في أسفل الصفحة واكتب: `I need work in Brussels`.

**فحص من سطر الأوامر (اختياري):** في نافذة طرفية ثانية، بينما الخادم يعمل:
```
curl http://localhost:3000/api/health
curl -X POST http://localhost:3000/api/ai/chat -H "Content-Type: application/json" -H "Origin: http://localhost:3000" -d "{\"message\":\"I need work\"}"
```
يجب أن يحتوي الناتج الأول على `"ready":true`، والثاني على `"status":"ok"`.

**ملاحظة:** افتح الموقع دائماً عبر `http://localhost:3000` وليس `127.0.0.1`، لأن حماية الطلبات تقبل العنوان المضبوط في `APP_URL` فقط.

## 7. إنشاء مدير (اختياري)
استخدم المتغيرات البيئية وليس سطر الأوامر، حتى لا تبقى كلمة المرور في سجل الطرفية:
- macOS/Linux: `ADMIN_EMAIL=you@example.org ADMIN_PASSWORD='كلمة مرور طويلة' npm run admin`
- Windows PowerShell: `$env:ADMIN_EMAIL='you@example.org'; $env:ADMIN_PASSWORD='كلمة مرور طويلة'; npm run admin`

## 8. النسخ الاحتياطي والاستعادة
```
npm run backup
node scripts/restore.js backups/<اسم-الملف>.sqlite
```
أوقف الخادم قبل الاستعادة.

## 9. ما الذي يعمل وما الذي لا يعمل بعد
راجع `ARCHITECTURE.md` القسم 11 للقائمة الكاملة. باختصار:
- يعمل محلياً: التصفح والبحث والإرسال للمراجعة والإبلاغ والحفظ والملف الشخصي والمساعد التجريبي والنسخ الاحتياطي.
- لم يُختبر بعد: تدفقات HTTP كاملة على جهازك (حتى تنفيذ `npm test`)، والموقع في متصفح حقيقي، والبريد عبر Brevo، والذكاء الاصطناعي المدفوع (موقوف).
