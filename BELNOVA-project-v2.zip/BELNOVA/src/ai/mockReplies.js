'use strict';
// Replies for the FREE test provider. They never name a job, home, organisation or link:
// the list of items is shown separately, and comes only from the database.
const T = {
  ar: { tag: '[وضع الاختبار: ليس ذكاءً اصطناعياً حقيقياً]', found: (n) => `وجدتُ ${n} عنصراً في قاعدة البيانات قد يناسب طلبك. هذه بيانات تجريبية وليست فرص عمل أو سكن حقيقية. تحقق من كل مصدر بنفسك قبل أي خطوة.`, none: 'لم أجد عنصراً مطابقاً في البيانات الحالية. جرّب كلمة أخرى، أو تصفح الأقسام مباشرة.', hello: 'مرحباً! اكتب ما تحتاجه: عمل، سكن، طعام، مساعدة أو خدمات.' },
  fr: { tag: '[Mode test : pas une vraie IA]', found: (n) => `J’ai trouvé ${n} élément(s) dans la base qui pourraient correspondre. Ce sont des données de test, pas de vraies offres d’emploi ou de logement. Vérifiez chaque source avant toute démarche.`, none: 'Aucun élément correspondant dans les données actuelles. Essayez un autre mot ou parcourez les sections.', hello: 'Bonjour ! Dites-moi ce dont vous avez besoin : emploi, logement, alimentation, aide ou services.' },
  en: { tag: '[Test mode: not a real AI model]', found: (n) => `I found ${n} item(s) in the database that may match. This is test data, not real jobs or housing. Check each source yourself before acting.`, none: 'No matching item in the current data. Try another word or browse the sections.', hello: 'Hello! Tell me what you need: work, housing, food, help or services.' },
  es: { tag: '[Modo prueba: no es una IA real]', found: (n) => `Encontré ${n} elemento(s) en la base de datos que podrían coincidir. Son datos de prueba, no ofertas reales de trabajo o vivienda. Verifica cada fuente antes de actuar.`, none: 'No hay elementos que coincidan con los datos actuales. Prueba otra palabra o explora las secciones.', hello: '¡Hola! Cuéntame qué necesitas: trabajo, vivienda, comida, ayuda o servicios.' },
  de: { tag: '[Testmodus: keine echte KI]', found: (n) => `Ich habe ${n} Eintrag/Einträge in der Datenbank gefunden, die passen könnten. Das sind Testdaten, keine echten Stellen oder Wohnungen. Prüfen Sie jede Quelle selbst, bevor Sie handeln.`, none: 'Keine passenden Einträge in den aktuellen Daten. Versuchen Sie ein anderes Wort oder stöbern Sie in den Bereichen.', hello: 'Hallo! Sagen Sie mir, was Sie brauchen: Arbeit, Wohnen, Essen, Hilfe oder Dienste.' },
  nl: { tag: '[Testmodus: geen echte AI]', found: (n) => `Ik heb ${n} item(s) in de database gevonden die misschien passen. Dit zijn testgegevens, geen echte vacatures of woningen. Controleer elke bron zelf voordat je iets onderneemt.`, none: 'Geen passend item in de huidige gegevens. Probeer een ander woord of blader door de secties.', hello: 'Hallo! Vertel me wat je nodig hebt: werk, wonen, eten, hulp of diensten.' },
  pt: { tag: '[Modo de teste: não é uma IA real]', found: (n) => `Encontrei ${n} item(ns) no banco de dados que podem combinar. São dados de teste, não vagas ou moradias reais. Verifique cada fonte antes de agir.`, none: 'Nenhum item correspondente nos dados atuais. Tente outra palavra ou navegue pelas seções.', hello: 'Olá! Diga o que você precisa: emprego, habitação, alimentação, apoio ou serviços.' },
  it: { tag: '[Modalità test: non è un’IA reale]', found: (n) => `Ho trovato ${n} elemento/i nel database che potrebbero corrispondere. Sono dati di prova, non lavori o alloggi reali. Verifica ogni fonte prima di agire.`, none: 'Nessun elemento corrispondente nei dati attuali. Prova un’altra parola o sfoglia le sezioni.', hello: 'Ciao! Dimmi di cosa hai bisogno: lavoro, casa, cibo, aiuto o servizi.' },
};

// Heuristic language detection. Good enough for a test provider; the real model detects languages itself.
function detectLang(text) {
  if (/[\u0600-\u06FF]/.test(text)) return 'ar';
  const s = String(text).toLowerCase();
  const rules = [
    ['fr', /\b(bonjour|je|cherche|travail|logement|chambre|besoin|merci)\b/],
    ['es', /\b(hola|busco|trabajo|vivienda|necesito|gracias)\b/],
    ['de', /\b(ich|suche|arbeit|wohnung|hallo|brauche|danke)\b/],
    ['nl', /\b(ik|zoek|werk|woning|hallo|nodig|dank)\b/],
    ['pt', /\b(olá|ola|procuro|emprego|preciso|obrigado)\b/],
    ['it', /\b(ciao|cerco|lavoro|ho bisogno|grazie)\b/],
  ];
  for (const [lang, re] of rules) if (re.test(s)) return lang;
  return 'en';
}

// count = number of catalogue items the assistant retrieved for this message
function mockReply(userText, count) {
  const t = T[detectLang(userText)];
  const body = count > 0 ? t.found(count) : (userText.trim().length < 12 ? t.hello : t.none);
  return `${t.tag} ${body}`;
}

module.exports = { mockReply, detectLang, T };
