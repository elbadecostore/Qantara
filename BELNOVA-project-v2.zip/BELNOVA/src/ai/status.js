'use strict';
// Non-secret status of BELNOVA AI, in the same order the spending guard checks it.
function aiStatus(cfg, provider) {
  const configured = Boolean(provider && provider.configured());
  const paid = provider ? provider.paid !== false : true;
  let reason = 'ready';
  if (!cfg.aiEnabled) reason = 'ai_disabled';
  else if (!configured) reason = 'ai_not_configured';
  else if (paid && !(cfg.priceInPerMTok > 0 && cfg.priceOutPerMTok > 0)) reason = 'ai_prices_not_set';
  else if (paid && !(cfg.monthlyLimitEur > 0)) reason = 'ai_limit_not_set';
  return {
    enabled: cfg.aiEnabled,
    provider: provider ? provider.name : cfg.aiProvider,
    free: provider ? provider.paid === false : false,
    configured,
    ready: reason === 'ready',
    reason,
  };
}
module.exports = { aiStatus };
