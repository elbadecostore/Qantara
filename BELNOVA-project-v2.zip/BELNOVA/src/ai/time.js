'use strict';
const sqlTime = (d = new Date()) => d.toISOString().slice(0, 19).replace('T', ' ');
module.exports = { sqlTime };
