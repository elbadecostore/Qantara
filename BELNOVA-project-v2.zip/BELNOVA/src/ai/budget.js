'use strict';
// Spending guard. Fails closed: if any limit or price is missing, no paid call is made.
const { sqlTime } = require('./time');

function estimateCost(cfg, inTok, outTok) {
  return (inTok * cfg.priceInPerMTok + outTok * cfg.priceOutPerMTok) / 1e6;
}

function monthStart(now) { return sqlTime(new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), 1))); }
function dayStart(now) { return sqlTime(new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()))); }

function spentSince(db, since) {
  return db.prepare('SELECT COALESCE(SUM(cost_eur),0) AS s FROM ai_usage WHERE created_at >= ?').get(since).s;
}
function callsSince(db, since, userId = null) {
  if (userId == null) return db.prepare('SELECT COUNT(*) AS n FROM ai_usage WHERE created_at >= ?').get(since).n;
  return db.prepare('SELECT COUNT(*) AS n FROM ai_usage WHERE created_at >= ? AND user_id = ?').get(since, userId).n;
}

// Returns {ok:true, reserve} or {ok:false, reason}. Reasons are codes the frontend translates.
function gate(db, cfg, provider, { userId = null, now = new Date(), inputTokens = 0 }) {
  if (!cfg.aiEnabled) return { ok: false, reason: 'ai_disabled' };
  if (!provider || !provider.configured()) return { ok: false, reason: 'ai_not_configured' };
  if (provider.paid === false) return { ok: true, reserve: 0 }; // free test provider: no spend to guard
  if (!(cfg.priceInPerMTok > 0 && cfg.priceOutPerMTok > 0)) return { ok: false, reason: 'ai_prices_not_set' };
  if (!(cfg.monthlyLimitEur > 0)) return { ok: false, reason: 'ai_limit_not_set' };
  if (callsSince(db, dayStart(now)) >= cfg.dailyLimitGlobal) return { ok: false, reason: 'ai_daily_limit' };
  if (userId != null && callsSince(db, dayStart(now), userId) >= cfg.dailyLimitPerUser) return { ok: false, reason: 'ai_user_daily_limit' };
  const reserve = estimateCost(cfg, inputTokens, cfg.aiMaxOutputTokens);
  if (spentSince(db, monthStart(now)) + reserve > cfg.monthlyLimitEur) return { ok: false, reason: 'ai_monthly_limit' };
  return { ok: true, reserve };
}

function record(db, cfg, provider, { userId = null, inputTokens, outputTokens }) {
  const cost = provider.paid === false ? 0 : estimateCost(cfg, inputTokens, outputTokens);
  db.prepare('INSERT INTO ai_usage(user_id,provider,model,input_tokens,output_tokens,cost_eur) VALUES(?,?,?,?,?,?)')
    .run(userId, provider.name, provider.model, inputTokens, outputTokens, cost);
  return cost;
}

function monthlyReport(db, cfg, now = new Date()) {
  return {
    spentEur: spentSince(db, monthStart(now)),
    limitEur: cfg.monthlyLimitEur,
    callsToday: callsSince(db, dayStart(now)),
    dailyLimitGlobal: cfg.dailyLimitGlobal,
  };
}

module.exports = { estimateCost, gate, record, monthlyReport };
