'use strict';
// BELNOVA AI: answers only from the database catalogue, never from invented data.
const budget = require('./budget');
const svc = require('../services');
const { detectCategories } = require('../categories');
const { newToken, hashToken } = require('../security');

const SYSTEM_PROMPT = `You are BELNOVA AI, the assistant inside the BELNOVA website (Brussels, Belgium).
BELNOVA helps people find work, housing, food, support and services.
- Reply in the same language as the user.
- Recommend ONLY items from the Catalogue given in the message. Quote their names and links exactly.
- Official reference sites are NOT verified opportunities. Tell the user to check every opportunity with the source.
- Never invent jobs, housing, prices, availability, eligibility rules, contacts or partnerships.
- If the Catalogue has no match, say so plainly and suggest the next practical step.
- Ask at most one clarifying question, and only when it is essential.
- Keep answers short. Do not ask for identity documents, passport, or immigration details.`;

// Catalogue retrieval from the database: official sources and approved community listings.
function retrieve(db, message, limit = 8) {
  const out = [], seen = new Set();
  const add = (x) => { const k = x.type + x.id; if (!seen.has(k) && out.length < limit) { seen.add(k); out.push(x); } };
  const fromSource = (s) => ({ type: 'source', id: s.id, name: s.name, categories: s.categories.join(','), city: s.region, url: s.official_url, verification: 'official_reference' });
  const fromListing = (l) => ({ type: 'listing', id: l.id, name: l.title, categories: l.category, city: l.city, url: l.url, verification: l.verification });
  for (const c of detectCategories(message)) {
    for (const s of svc.listDirectory(db, { category: c })) add(fromSource(s));
    for (const l of svc.searchListings(db, { category: c })) add(fromListing(l));
  }
  const tokens = [...new Set(String(message).toLowerCase().split(/[^\p{L}\p{N}]+/u).filter((t) => t.length >= 3))].slice(0, 8);
  for (const t of tokens) {
    for (const s of svc.listDirectory(db, { q: t })) add(fromSource(s));
    for (const l of svc.searchListings(db, { q: t })) add(fromListing(l));
  }
  return out;
}

const HISTORY_TURNS = 8;

// Conversations are addressed by an unguessable token (only its hash is stored). Anonymous conversations
// are readable by whoever holds the token; owned conversations only by their owner.
function findConversation(db, token, user) {
  const c = db.prepare('SELECT id, user_id FROM ai_conversations WHERE token_hash = ?').get(hashToken(String(token)));
  if (!c) return null;
  if (c.user_id !== null && (!user || c.user_id !== user.id)) return null;
  return c;
}

async function answer({ db, cfg, provider, user = null, conversationToken = null, message, now = new Date() }) {
  const text = String(message ?? '').replace(/[\u0000-\u001f\u007f]/g, ' ').trim().slice(0, 2000);
  if (text.length < 1) throw new svc.AppError('empty_message');

  let convId = null;
  let history = [];
  if (conversationToken) {
    const c = findConversation(db, conversationToken, user);
    if (!c) throw new svc.AppError('not_found', 404);
    convId = c.id;
    history = db.prepare('SELECT role, content FROM ai_messages WHERE conversation_id = ? ORDER BY id DESC LIMIT ?')
      .all(convId, HISTORY_TURNS).reverse();
  }

  const items = retrieve(db, text);
  const catalogue = items.length
    ? items.map((i, n) => `[${n + 1}] ${i.type} | ${i.name} | ${i.categories} | ${i.city} | ${i.url || 'no link'} | ${i.verification}`).join('\n')
    : '(no matching items in the catalogue)';
  const messages = [
    ...history.map((h) => ({ role: h.role, content: h.content })),
    { role: 'user', content: `Catalogue:\n${catalogue}\n\nUser message:\n${text}` },
  ];

  const inputTokens = Math.ceil((SYSTEM_PROMPT.length + JSON.stringify(messages).length) / 3);
  const gate = budget.gate(db, cfg, provider, { userId: user ? user.id : null, now, inputTokens });
  if (!gate.ok) return { status: 'unavailable', code: gate.reason, items: [] };

  let res;
  try {
    res = await provider.complete({ system: SYSTEM_PROMPT, messages, maxTokens: cfg.aiMaxOutputTokens });
  } catch {
    return { status: 'unavailable', code: 'ai_provider_error', items: [] };
  }
  budget.record(db, cfg, provider, { userId: user ? user.id : null, inputTokens: res.inputTokens, outputTokens: res.outputTokens });

  let token = conversationToken;
  svc.tx(db, () => {
    if (!convId) {
      token = newToken();
      convId = Number(db.prepare('INSERT INTO ai_conversations(user_id, token_hash) VALUES(?,?)')
        .run(user ? user.id : null, hashToken(token)).lastInsertRowid);
    }
    db.prepare("INSERT INTO ai_messages(conversation_id,role,content) VALUES(?,'user',?)").run(convId, text);
    db.prepare("INSERT INTO ai_messages(conversation_id,role,content) VALUES(?,'assistant',?)").run(convId, res.text.slice(0, 4000));
  });
  return { status: 'ok', conversationToken: token, reply: res.text, items };
}

module.exports = { answer, retrieve, findConversation, SYSTEM_PROMPT };
