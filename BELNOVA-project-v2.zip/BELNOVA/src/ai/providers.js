'use strict';
const { mockReply } = require('./mockReplies');
// Provider-independent: the assistant only uses { name, model, configured(), complete() }.
// Adding another provider means adding one function here; nothing else changes.

function anthropic(cfg) {
  return {
    name: 'anthropic',
    model: cfg.aiModel,
    configured: () => Boolean(cfg.aiApiKey && cfg.aiModel),
    async complete({ system, messages, maxTokens }) {
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'content-type': 'application/json', 'x-api-key': cfg.aiApiKey, 'anthropic-version': '2023-06-01' },
        body: JSON.stringify({ model: cfg.aiModel, max_tokens: maxTokens, system, messages }),
        signal: AbortSignal.timeout(20000),
      });
      if (!r.ok) throw new Error(`provider_http_${r.status}`);
      const j = await r.json();
      return {
        text: j.content.filter((b) => b.type === 'text').map((b) => b.text).join(''),
        inputTokens: j.usage.input_tokens,
        outputTokens: j.usage.output_tokens,
      };
    },
  };
}

// Free, deterministic provider for local testing only. It never calls a model and never costs money.
// It describes the catalogue items it is given (counts only) in the language of the user.
function mock() {
  return {
    name: 'mock', model: 'mock-v1', paid: false,
    configured: () => true,
    async complete({ messages }) {
      const last = messages[messages.length - 1].content;
      const userText = (last.split('User message:\n')[1] || '').trim();
      const count = (last.match(/^\[\d+\] /gm) || []).length;
      const text = mockReply(userText, count);
      return { text, inputTokens: Math.ceil(last.length / 4), outputTokens: Math.ceil(text.length / 4) };
    },
  };
}

function createProvider(cfg) {
  if (cfg.aiProvider === 'mock') return mock();
  if (cfg.aiProvider === 'anthropic') return anthropic(cfg);
  return null;
}

module.exports = { createProvider };
