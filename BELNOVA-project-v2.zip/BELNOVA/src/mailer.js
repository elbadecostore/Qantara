'use strict';
// Provider-independent email. Tokens are sent in the link, never logged.
class MemoryMailer {
  constructor() { this.sent = []; }
  async send(msg) { this.sent.push(msg); }
}
class ConsoleMailer {
  // Development only: prints recipient and subject, never the body (the body contains the token).
  async send({ to, subject }) { console.log(`[mail:dev] to=${to} subject="${subject}" (body hidden)`); }
}
class UnconfiguredMailer {
  async send() { const e = new Error('mail_not_configured'); e.code = 'mail_not_configured'; throw e; }
}
// Brevo transactional email (https://api.brevo.com/v3/smtp/email, header "api-key").
// Inert unless MAIL_SEND_ENABLED=true AND a key is set. Nothing is sent before the owner approves.
class BrevoMailer {
  constructor(cfg, fetchImpl = globalThis.fetch) {
    this.cfg = cfg; this.fetch = fetchImpl;
  }
  configured() { return Boolean(this.cfg.brevoApiKey && this.cfg.mailFrom); }
  async send({ to, subject, text }) {
    if (!this.cfg.mailSendEnabled) { const e = new Error('mail_send_disabled'); e.code = 'mail_not_configured'; throw e; }
    if (!this.configured()) { const e = new Error('mail_not_configured'); e.code = 'mail_not_configured'; throw e; }
    const r = await this.fetch('https://api.brevo.com/v3/smtp/email', {
      method: 'POST',
      headers: { 'content-type': 'application/json', accept: 'application/json', 'api-key': this.cfg.brevoApiKey },
      body: JSON.stringify({ sender: { email: this.cfg.mailFrom, name: 'BELNOVA' }, to: [{ email: to }], subject, textContent: text }),
      signal: AbortSignal.timeout(10000),
    });
    if (!r.ok) throw new Error(`brevo_http_${r.status}`);
    return { ok: true };
  }
}

function createMailer(cfg) {
  if (cfg.mailProvider === 'brevo') return new BrevoMailer(cfg);
  if (cfg.mailProvider === 'console') return new ConsoleMailer();
  if (cfg.mailProvider === 'memory') return new MemoryMailer();
  return new UnconfiguredMailer(); // production default until an SMTP/API provider is chosen
}
module.exports = { createMailer, MemoryMailer, ConsoleMailer, UnconfiguredMailer, BrevoMailer };
