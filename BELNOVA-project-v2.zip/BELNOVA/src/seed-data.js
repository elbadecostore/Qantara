'use strict';
// Official reference sites only. These are NOT listings. Every URL must be re-checked by a human
// before publication, and no content is imported from them. permission_status stays 'none'.
module.exports = [
  { slug: 'actiris', name: 'Actiris', kind: 'public_body', official_url: 'https://www.actiris.brussels/', categories: ['work', 'support'], tags: 'emploi job work travail werk trabajo عمل وظيفة' },
  { slug: 'vdab', name: 'VDAB', kind: 'public_body', region: 'Flanders', official_url: 'https://www.vdab.be/', categories: ['work'], tags: 'werk job work vdab' },
  { slug: 'leforem', name: 'Le Forem', kind: 'public_body', region: 'Wallonia', official_url: 'https://www.leforem.be/', categories: ['work'], tags: 'emploi forem job travail' },
  { slug: 'jobat', name: 'Jobat', kind: 'commercial_portal', official_url: 'https://www.jobat.be/', categories: ['work'], tags: 'jobat job emploi work' },
  { slug: 'stepstone', name: 'StepStone', kind: 'commercial_portal', official_url: 'https://www.stepstone.be/', categories: ['work'], tags: 'stepstone job emploi work' },
  { slug: 'immoweb', name: 'Immoweb', kind: 'commercial_portal', official_url: 'https://www.immoweb.be/', categories: ['housing'], tags: 'immoweb housing logement chambre غرفة سكن شقة' },
  { slug: 'immovlan', name: 'Immovlan', kind: 'commercial_portal', official_url: 'https://www.immovlan.be/', categories: ['housing'], tags: 'immovlan housing logement studio' },
  { slug: 'housinganywhere', name: 'HousingAnywhere', kind: 'commercial_portal', official_url: 'https://housinganywhere.com/', categories: ['housing'], tags: 'housinganywhere housing room chambre' },
  { slug: 'samusocial', name: 'Samusocial de Bruxelles', kind: 'nonprofit', official_url: 'https://samusocial.be/', categories: ['food', 'support', 'housing'], tags: 'samusocial food meal aide shelter طعام مساعدة' },
  { slug: 'foodbanks', name: 'Foodbanks.be', kind: 'nonprofit', official_url: 'https://www.foodbanks.be/', categories: ['food'], tags: 'foodbanks food bank banque voedsel طعام غذاء' },
  { slug: 'doucheflux', name: 'Doucheflux', kind: 'nonprofit', official_url: 'https://www.doucheflux.be/', categories: ['services'], tags: 'doucheflux shower douche hygiene' },
];
