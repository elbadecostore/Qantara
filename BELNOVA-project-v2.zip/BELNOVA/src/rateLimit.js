'use strict';
// Rate limiting with a pluggable store. Start with memory (one process). When BELNOVA runs on several
// instances, use SqliteStore (shared file) or a Redis store with the same incr() contract.
class MemoryStore {
  constructor() { this.map = new Map(); }
  async incr(key, windowMs, now) {
    if (this.map.size > 10000) for (const [k, v] of this.map) if (now >= v.resetAt) this.map.delete(k);
    const e = this.map.get(key);
    if (!e || now >= e.resetAt) {
      const n = { count: 1, resetAt: now + windowMs };
      this.map.set(key, n);
      return n;
    }
    e.count++;
    return e;
  }
}

class SqliteStore {
  constructor(db) { this.db = db; }
  async incr(key, windowMs, now) {
    const reset = now + windowMs;
    this.db.prepare(`INSERT INTO rate_limits(key,count,reset_at) VALUES(?,1,?)
      ON CONFLICT(key) DO UPDATE SET
        count = CASE WHEN rate_limits.reset_at <= ? THEN 1 ELSE rate_limits.count + 1 END,
        reset_at = CASE WHEN rate_limits.reset_at <= ? THEN ? ELSE rate_limits.reset_at END`)
      .run(key, reset, now, now, reset);
    const r = this.db.prepare('SELECT count, reset_at AS resetAt FROM rate_limits WHERE key = ?').get(key);
    return { count: r.count, resetAt: r.resetAt };
  }
}

class RateLimiter {
  constructor(store = new MemoryStore()) { this.store = store; }
  async hit(key, limit, windowMs, now = Date.now()) {
    const { count, resetAt } = await this.store.incr(key, windowMs, now);
    if (count > limit) return { ok: false, remaining: 0, retryAfter: Math.max(1, Math.ceil((resetAt - now) / 1000)) };
    return { ok: true, remaining: limit - count, retryAfter: 0 };
  }
}

module.exports = { RateLimiter, MemoryStore, SqliteStore };
