'use strict';
const CATEGORIES = ['work', 'housing', 'food', 'support', 'services', 'community'];
// Keywords in the languages BELNOVA supports, used to detect combined needs ("job and a room").
const CATEGORY_WORDS = {
  work: ['job', 'work', 'emploi', 'travail', 'werk', 'trabajo', 'trabalho', 'lavoro', 'arbeit', 'baan', 'عمل', 'وظيفة', 'شغل'],
  housing: ['room', 'flat', 'apartment', 'studio', 'housing', 'logement', 'chambre', 'kamer', 'wonen', 'wohnung', 'vivienda', 'habitação', 'casa', 'غرفة', 'سكن', 'شقة'],
  food: ['food', 'meal', 'repas', 'eten', 'voedsel', 'comida', 'cibo', 'essen', 'طعام', 'وجبة', 'غذاء'],
  support: ['rights', 'droits', 'legal', 'recht', 'hulp', 'derechos', 'aiuto', 'direitos', 'حقوق', 'قانون'],
  services: ['shower', 'douche', 'translation', 'traduction', 'servicios', 'servizi', 'ترجمة'],
  community: ['volunteer', 'bénévolat', 'community', 'communauté', 'gemeenschap', 'comunidad', 'تطوع', 'مجتمع'],
};
function detectCategories(text) {
  const t = String(text).toLowerCase();
  return CATEGORIES.filter((c) => CATEGORY_WORDS[c].some((w) => t.includes(w)));
}
module.exports = { CATEGORIES, CATEGORY_WORDS, detectCategories };
