'use strict';
// All settings come from environment variables. Safe defaults: AI off, no paid mail, strict cookies.
const { normalizeOrigin } = require('./guards');

function num(v, d) {
  if (v === undefined || v === '') return d;
  const n = Number(v);
  return Number.isFinite(n) ? n : d;
}
function load(env = process.env) {
  const appUrl = env.APP_URL || 'http://localhost:3000';
  const extra = (env.APP_ORIGINS || '').split(',').map((s) => s.trim()).filter(Boolean);
  const allowedOrigins = [...new Set([appUrl, ...extra].map(normalizeOrigin).filter(Boolean))];
  return {
    nodeEnv: env.NODE_ENV || 'development',
    port: num(env.PORT, 3000),
    appUrl,
    allowedOrigins,
    dbPath: env.DB_PATH || './data/belnova.sqlite',
    trustProxy: env.TRUST_PROXY === 'true',
    cookieSecure: env.COOKIE_SECURE ? env.COOKIE_SECURE === 'true' : env.NODE_ENV === 'production',
    mailProvider: env.MAIL_PROVIDER || 'none',
    mailSendEnabled: env.MAIL_SEND_ENABLED === 'true', // stays false until the owner approves real sending
    mailFrom: env.MAIL_FROM || '',
    brevoApiKey: env.BREVO_API_KEY || '',
    aiEnabled: env.AI_ENABLED === 'true',
    aiProvider: env.AI_PROVIDER || 'anthropic', // 'mock' for free integration tests, 'anthropic' when approved
    aiApiKey: env.AI_API_KEY || env.ANTHROPIC_API_KEY || '',
    aiModel: env.AI_MODEL || '',
    aiMaxOutputTokens: num(env.AI_MAX_OUTPUT_TOKENS, 500),
    monthlyLimitEur: num(env.AI_MONTHLY_LIMIT_EUR, 0),
    dailyLimitGlobal: num(env.AI_DAILY_LIMIT_GLOBAL, 200),
    dailyLimitPerUser: num(env.AI_DAILY_LIMIT_PER_USER, 20),
    priceInPerMTok: num(env.AI_PRICE_INPUT_EUR_PER_MTOK, 0),
    priceOutPerMTok: num(env.AI_PRICE_OUTPUT_EUR_PER_MTOK, 0),
  };
}
module.exports = { load };
