'use strict';
const { load } = require('./config');
const { open } = require('./db');
const { createProvider } = require('./ai/providers');
const { aiStatus } = require('./ai/status');
const { createApp } = require('./server');

const cfg = load();
const provider = createProvider(cfg);
const db = open(cfg.dbPath);
const app = createApp({ db, cfg, provider });
const ai = aiStatus(cfg, provider);
app.listen(cfg.port, () => {
  console.log(`BELNOVA on http://localhost:${cfg.port} (db: ${cfg.dbPath})`);
  console.log(`BELNOVA AI: ${ai.ready ? `ready (${ai.provider}${ai.free ? ', free test provider' : ''})` : `NOT ready, reason: ${ai.reason}`}`);
});
