'use strict';
// Account lifecycle: email verification, password reset, password change, account deletion.
// Tokens are random, single-use, expire, and only their SHA-256 hash is stored.
const svc = require('./services');
const { verifyPassword, newToken, hashToken, hashPassword } = require('./security');
const { sqlTime } = require('./ai/time');

const { AppError, tx, audit } = svc;
const TTL_MINUTES = { verify_email: 48 * 60, reset_password: 60 };
const PASSWORD_MIN = 12, PASSWORD_MAX = 200;

function checkPassword(p) {
  if (typeof p !== 'string' || p.length < PASSWORD_MIN || p.length > PASSWORD_MAX) throw new AppError('weak_password');
}

// Must run inside tx(): issues a new token and invalidates older unused tokens of the same purpose.
function issueTokenRaw(db, userId, purpose) {
  db.prepare('DELETE FROM auth_tokens WHERE user_id = ? AND purpose = ? AND used_at IS NULL').run(userId, purpose);
  const raw = newToken();
  db.prepare('INSERT INTO auth_tokens(user_id,purpose,token_hash,expires_at) VALUES(?,?,?,?)')
    .run(userId, purpose, hashToken(raw), sqlTime(new Date(Date.now() + TTL_MINUTES[purpose] * 60000)));
  return raw;
}

// Must run inside tx(): marks the token used and returns its user id, or throws.
function consumeTokenRaw(db, raw, purpose) {
  const r = db.prepare('SELECT id, user_id, expires_at, used_at FROM auth_tokens WHERE token_hash = ? AND purpose = ?')
    .get(hashToken(String(raw || '')), purpose);
  if (!r || r.used_at || r.expires_at <= sqlTime()) throw new AppError('invalid_or_expired_token', 400);
  db.prepare("UPDATE auth_tokens SET used_at = datetime('now') WHERE id = ?").run(r.id);
  return r.user_id;
}

async function sendVerificationEmail(db, mailer, cfg, user) {
  const raw = tx(db, () => issueTokenRaw(db, user.id, 'verify_email'));
  await mailer.send({ to: user.email, subject: 'BELNOVA: confirm your email',
    text: `Confirm your email: ${cfg.appUrl}/verify#token=${raw}\nThis link expires in 48 hours. If you did not create an account, ignore this message.` });
}

function confirmEmail(db, token) {
  tx(db, () => {
    const uid = consumeTokenRaw(db, token, 'verify_email');
    db.prepare("UPDATE users SET email_verified_at = datetime('now') WHERE id = ?").run(uid);
  });
}

// Always returns the same answer, so the endpoint cannot be used to discover which emails have accounts.
async function requestPasswordReset(db, mailer, cfg, email) {
  const u = db.prepare('SELECT id, email, disabled FROM users WHERE email = ?')
    .get(String(email || '').trim().toLowerCase());
  if (u && !u.disabled) {
    const raw = tx(db, () => issueTokenRaw(db, u.id, 'reset_password'));
    try {
      await mailer.send({ to: u.email, subject: 'BELNOVA: reset your password',
        text: `Reset your password: ${cfg.appUrl}/reset#token=${raw}\nThis link expires in 60 minutes. If you did not ask for this, ignore this message.` });
    } catch (e) {
      audit(db, null, 'password_reset.mail_failed', `user:${u.id}`);
    }
  }
  return { ok: true };
}

// Resetting the password proves control of the mailbox, and it signs out every session.
function resetPassword(db, token, newPassword) {
  checkPassword(newPassword);
  const hash = hashPassword(newPassword);
  tx(db, () => {
    const uid = consumeTokenRaw(db, token, 'reset_password');
    db.prepare("UPDATE users SET password_hash = ?, email_verified_at = COALESCE(email_verified_at, datetime('now')) WHERE id = ?").run(hash, uid);
    db.prepare('DELETE FROM sessions WHERE user_id = ?').run(uid);
    audit(db, uid, 'password.reset', `user:${uid}`);
  });
}

// Changing the password requires the current one and signs out every other session (the caller re-issues its own).
function changePassword(db, userId, current, newPassword) {
  const u = db.prepare('SELECT password_hash FROM users WHERE id = ?').get(userId);
  if (!u || !verifyPassword(String(current ?? ''), u.password_hash)) throw new AppError('invalid_credentials', 403);
  checkPassword(newPassword);
  const hash = hashPassword(newPassword);
  tx(db, () => {
    db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(hash, userId);
    db.prepare('DELETE FROM sessions WHERE user_id = ?').run(userId);
    audit(db, userId, 'password.changed', `user:${userId}`);
  });
}

// Scrubs anything that can identify a person from text kept after account deletion.
function scrubIdentifiers(text) {
  return String(text ?? '')
    .replace(/[\w.+-]+@[\w-]+\.[\w.-]+/g, '[removed]')                 // e-mail addresses
    .replace(/(\+?\d[\d\s().-]{7,}\d)/g, '[removed]')                 // phone-like numbers
    .replace(/https?:\/\/[^\s]+/gi, (u) => (/instagram|facebook|twitter|tiktok|linkedin|whatsapp|t\.me|wa\.me/i.test(u) ? '[removed]' : u)); // personal social links
}

// Deletes the account and everything BELNOVA holds about it. Requires the password.
// Default: the user's community submissions are deleted with the account.
// Opt-in only: keepContributionsAnonymously=true, and only for approved submissions, which are
// stripped of personal details and detached from the account (no owner is stored afterwards).
function deleteAccount(db, userId, password, { keepContributionsAnonymously = false } = {}) {
  const u = db.prepare('SELECT password_hash FROM users WHERE id = ?').get(userId);
  if (!u || !verifyPassword(String(password ?? ''), u.password_hash)) throw new AppError('invalid_credentials', 403);
  tx(db, () => {
    if (keepContributionsAnonymously) {
      const rows = db.prepare("SELECT id, title, summary, tags FROM listings WHERE submitted_by = ? AND status = 'approved'").all(userId);
      for (const r of rows) {
        db.prepare("UPDATE listings SET title = ?, summary = ?, tags = ?, submitted_by = NULL, moderation_note = NULL, updated_at = datetime('now') WHERE id = ?")
          .run(scrubIdentifiers(r.title), scrubIdentifiers(r.summary), scrubIdentifiers(r.tags), r.id);
        audit(db, null, 'listing.anonymised_on_deletion', `listing:${r.id}`);
      }
    }
    const ids = db.prepare('SELECT id FROM listings WHERE submitted_by = ?').all(userId).map((r) => r.id);
    for (const id of ids) db.prepare("DELETE FROM saved_items WHERE item_type = 'listing' AND item_id = ?").run(id);
    db.prepare('DELETE FROM listings WHERE submitted_by = ?').run(userId); // cascades reports on those listings
    db.prepare('DELETE FROM saved_items WHERE user_id = ?').run(userId);
    db.prepare('DELETE FROM profiles WHERE user_id = ?').run(userId);
    db.prepare('DELETE FROM ai_conversations WHERE user_id = ?').run(userId); // cascades ai_messages
    db.prepare('UPDATE audit_log SET actor_id = NULL WHERE actor_id = ?').run(userId);
    db.prepare('DELETE FROM users WHERE id = ?').run(userId); // cascades sessions, auth_tokens, messages; SET NULL on ai_usage, reports
    audit(db, null, 'user.deleted', null); // no identifier kept after deletion
  });
}

module.exports = { sendVerificationEmail, confirmEmail, requestPasswordReset, resetPassword, changePassword, deleteAccount, checkPassword, scrubIdentifiers };
