'use strict';
const crypto = require('crypto');

const N = 16384, R = 8, P = 1, KEYLEN = 64;

function hashPassword(password) {
  const salt = crypto.randomBytes(16);
  const h = crypto.scryptSync(String(password), salt, KEYLEN, { N, r: R, p: P });
  return ['scrypt', N, R, P, salt.toString('base64'), h.toString('base64')].join('$');
}

function verifyPassword(password, stored) {
  const parts = String(stored).split('$');
  if (parts.length !== 6 || parts[0] !== 'scrypt') return false;
  const [, n, r, p, s, h] = parts;
  const expected = Buffer.from(h, 'base64');
  const got = crypto.scryptSync(String(password), Buffer.from(s, 'base64'), expected.length, { N: +n, r: +r, p: +p });
  return crypto.timingSafeEqual(got, expected);
}

const newToken = () => crypto.randomBytes(32).toString('base64url');
const hashToken = (t) => crypto.createHash('sha256').update(t).digest('hex');

module.exports = { hashPassword, verifyPassword, newToken, hashToken };
