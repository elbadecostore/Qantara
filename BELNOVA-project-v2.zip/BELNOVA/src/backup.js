'use strict';
// SQLite backups without the sqlite3 CLI: VACUUM INTO writes a consistent copy even while the app runs.
const fs = require('fs');
const path = require('path');
const { DatabaseSync } = require('node:sqlite');

function backup(db, destFile) {
  if (fs.existsSync(destFile)) throw new Error('backup_target_exists');
  fs.mkdirSync(path.dirname(path.resolve(destFile)), { recursive: true });
  db.prepare('VACUUM INTO ?').run(destFile);
  verify(destFile);
  return destFile;
}

// Opens a file read-only-in-spirit and checks integrity and that it is a BELNOVA database.
function verify(file) {
  const d = new DatabaseSync(file);
  try {
    const integrity = d.prepare('PRAGMA integrity_check').get();
    const ok = Object.values(integrity)[0] === 'ok';
    if (!ok) throw new Error('backup_integrity_failed');
    const hasMigrations = d.prepare("SELECT 1 FROM sqlite_master WHERE type='table' AND name='schema_migrations'").get();
    if (!hasMigrations) throw new Error('not_a_belnova_database');
    return { ok: true, migrations: d.prepare('SELECT MAX(version) v FROM schema_migrations').get().v };
  } finally { d.close(); }
}

// Restore: refuses to overwrite an existing database unless force is set. Stop the server first.
function restore(backupFile, targetFile, { force = false } = {}) {
  verify(backupFile);
  if (fs.existsSync(targetFile) && !force) throw new Error('target_exists_use_force');
  for (const suffix of ['', '-wal', '-shm']) if (fs.existsSync(targetFile + suffix)) fs.rmSync(targetFile + suffix, { force: true });
  fs.mkdirSync(path.dirname(path.resolve(targetFile)), { recursive: true });
  fs.copyFileSync(backupFile, targetFile);
  return verify(targetFile);
}

module.exports = { backup, restore, verify };
