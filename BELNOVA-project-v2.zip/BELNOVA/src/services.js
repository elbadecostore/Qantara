'use strict';
// Business logic. Routes stay thin and call these functions, so they can be tested without HTTP.
const { hashPassword, verifyPassword, newToken, hashToken } = require('./security');
const { CATEGORIES } = require('./categories');

class AppError extends Error {
  constructor(code, status = 400) { super(code); this.code = code; this.status = status; }
}

const SESSION_DAYS = 14;
const EMAIL = /^[^\s@]{1,64}@[^\s@]{1,190}\.[^\s@]{2,}$/;
const DUMMY_HASH = hashPassword('timing-equaliser-not-a-real-password');
const sqlTime = (d = new Date()) => d.toISOString().slice(0, 19).replace('T', ' ');
const clean = (v, max) => String(v ?? '').replace(/[\u0000-\u001f\u007f]/g, ' ').trim().slice(0, max);
const escLike = (s) => s.replace(/[\\%_]/g, (m) => '\\' + m);
const LIKE_ESC = "ESCAPE '\\'";

function httpsUrl(u) {
  if (u == null || u === '') return null;
  let x;
  try { x = new URL(String(u)); } catch { throw new AppError('invalid_url'); }
  if (x.protocol !== 'https:') throw new AppError('invalid_url');
  return x.href;
}

function tx(db, fn) {
  db.exec('BEGIN IMMEDIATE');
  try { const r = fn(); db.exec('COMMIT'); return r; } catch (e) { db.exec('ROLLBACK'); throw e; }
}

// Defence in depth: role checks are enforced here too, not only in the HTTP layer.
// actor === null means a trusted local script (seed, bootstrap); HTTP handlers always pass req.user.
function assertRole(actor, roles) {
  if (!actor || !roles.includes(actor.role)) throw new AppError('forbidden', 403);
}

function audit(db, actorId, action, target = null) {
  db.prepare('INSERT INTO audit_log(actor_id,action,target) VALUES(?,?,?)').run(actorId ?? null, action, target);
}

// ---------- Accounts and sessions ----------
function createUser(db, email, password) {
  email = clean(email, 190).toLowerCase();
  if (!EMAIL.test(email)) throw new AppError('invalid_email');
  if (typeof password !== 'string' || password.length < 12 || password.length > 200) throw new AppError('weak_password');
  try {
    const r = db.prepare('INSERT INTO users(email,password_hash) VALUES(?,?)').run(email, hashPassword(password));
    return { id: Number(r.lastInsertRowid), email, role: 'user' };
  } catch (e) {
    if (/UNIQUE/.test(e.message)) throw new AppError('email_taken', 409);
    throw e;
  }
}

function authenticate(db, email, password) {
  const row = db.prepare('SELECT * FROM users WHERE email = ?').get(clean(email, 190).toLowerCase());
  const ok = verifyPassword(String(password ?? ''), row ? row.password_hash : DUMMY_HASH);
  if (!row || !ok || row.disabled) return null;
  return { id: row.id, email: row.email, role: row.role };
}

function createSession(db, userId) {
  const token = newToken();
  const expiresAt = sqlTime(new Date(Date.now() + SESSION_DAYS * 864e5));
  db.prepare('INSERT INTO sessions(token_hash,user_id,expires_at) VALUES(?,?,?)').run(hashToken(token), userId, expiresAt);
  return { token, expiresAt };
}

function userFromSession(db, token) {
  if (!token) return null;
  const r = db.prepare(`SELECT u.id,u.email,u.role,u.disabled,s.expires_at FROM sessions s
    JOIN users u ON u.id = s.user_id WHERE s.token_hash = ?`).get(hashToken(token));
  if (!r || r.disabled || r.expires_at <= sqlTime()) return null;
  return { id: r.id, email: r.email, role: r.role };
}

function destroySession(db, token) {
  if (token) db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(hashToken(token));
}

// ---------- Consent-based profile ----------
function saveProfile(db, userId, input) {
  if (input.consent !== true) throw new AppError('consent_required');
  const years = input.years === '' || input.years == null ? null : Number(input.years);
  if (years !== null && !(Number.isInteger(years) && years >= 0 && years <= 60)) throw new AppError('invalid_years');
  const budget = input.housing_budget_eur === '' || input.housing_budget_eur == null ? null : Number(input.housing_budget_eur);
  if (budget !== null && !(Number.isInteger(budget) && budget >= 0 && budget <= 100000)) throw new AppError('invalid_budget');
  const employment = input.employment ? clean(input.employment, 1) : null;
  if (employment !== null && !['f', 'p', 'a'].includes(employment)) throw new AppError('invalid_employment');
  db.prepare(`INSERT INTO profiles(user_id,skills,years,languages,employment,housing_budget_eur,consent_at,updated_at)
    VALUES(?,?,?,?,?,?,datetime('now'),datetime('now'))
    ON CONFLICT(user_id) DO UPDATE SET skills=excluded.skills, years=excluded.years, languages=excluded.languages,
      employment=excluded.employment, housing_budget_eur=excluded.housing_budget_eur, consent_at=excluded.consent_at, updated_at=excluded.updated_at`)
    .run(userId, clean(input.skills, 500), years, clean(input.languages, 200), employment, budget);
  return getProfile(db, userId);
}

function getProfile(db, userId) {
  return db.prepare('SELECT skills,years,languages,employment,housing_budget_eur,consent_at,updated_at FROM profiles WHERE user_id = ?').get(userId) || null;
}

// Deletes everything personal BELNOVA holds for the user (profile, saved items, AI conversations).
function deleteUserData(db, userId) {
  tx(db, () => {
    db.prepare('DELETE FROM profiles WHERE user_id = ?').run(userId);
    db.prepare('DELETE FROM saved_items WHERE user_id = ?').run(userId);
    db.prepare('DELETE FROM ai_conversations WHERE user_id = ?').run(userId);
    audit(db, userId, 'user.data_deleted', `user:${userId}`);
  });
}

// ---------- Saved items ----------
function saveItem(db, userId, type, id) {
  if (!['listing', 'source'].includes(type)) throw new AppError('invalid_type');
  const exists = type === 'listing'
    ? db.prepare("SELECT 1 FROM listings WHERE id = ? AND status = 'approved'").get(id)
    : db.prepare('SELECT 1 FROM sources WHERE id = ? AND active = 1').get(id);
  if (!exists) throw new AppError('not_found', 404);
  db.prepare('INSERT OR IGNORE INTO saved_items(user_id,item_type,item_id) VALUES(?,?,?)').run(userId, type, Number(id));
}

function removeItem(db, userId, type, id) {
  db.prepare('DELETE FROM saved_items WHERE user_id = ? AND item_type = ? AND item_id = ?').run(userId, type, Number(id));
}

function listSaved(db, userId) {
  return db.prepare(`SELECT sv.item_type AS type, sv.item_id AS id, sv.created_at,
      CASE WHEN sv.item_type = 'listing' THEN l.title ELSE s.name END AS name,
      CASE WHEN sv.item_type = 'listing' THEN l.url ELSE s.official_url END AS url,
      CASE WHEN sv.item_type = 'listing' THEN l.verification ELSE 'official_reference' END AS verification
    FROM saved_items sv
    LEFT JOIN listings l ON sv.item_type = 'listing' AND l.id = sv.item_id
    LEFT JOIN sources s ON sv.item_type = 'source' AND s.id = sv.item_id
    WHERE sv.user_id = ? ORDER BY sv.created_at DESC`).all(userId);
}

// ---------- Official source directory ----------
function listDirectory(db, { category, q } = {}) {
  const where = ['s.active = 1'], p = [];
  if (category) {
    if (!CATEGORIES.includes(category)) throw new AppError('invalid_category');
    where.push('EXISTS (SELECT 1 FROM source_categories c WHERE c.source_id = s.id AND c.category = ?)');
    p.push(category);
  }
  const term = clean(q, 100).toLowerCase();
  if (term) {
    where.push(`(lower(s.name) LIKE ? ${LIKE_ESC} OR lower(s.tags) LIKE ? ${LIKE_ESC})`);
    const like = `%${escLike(term)}%`; p.push(like, like);
  }
  return db.prepare(`SELECT s.id, s.slug, s.name, s.kind, s.region, s.official_url, s.access_method,
      s.permission_status, s.terms_checked_at,
      (SELECT group_concat(c.category) FROM source_categories c WHERE c.source_id = s.id) AS categories
    FROM sources s WHERE ${where.join(' AND ')} ORDER BY s.name`).all(...p)
    .map((r) => ({ ...r, categories: (r.categories || '').split(',').filter(Boolean), verification: 'official_reference' }));
}

// Admin-only. Any automated import needs an explicit, granted permission.
function upsertSource(db, actor, d) {
  if (actor !== null) assertRole(actor, ['admin']);
  const actorId = actor ? actor.id : null;
  const slug = clean(d.slug, 60);
  if (!/^[a-z0-9-]{2,60}$/.test(slug)) throw new AppError('invalid_slug');
  const name = clean(d.name, 120);
  if (!name) throw new AppError('invalid_name');
  if (!['public_body', 'nonprofit', 'commercial_portal'].includes(d.kind)) throw new AppError('invalid_kind');
  if (!['none', 'api', 'rss', 'partnership', 'manual_review'].includes(d.access_method)) throw new AppError('invalid_access');
  if (!['none', 'requested', 'granted', 'refused'].includes(d.permission_status)) throw new AppError('invalid_permission');
  if (['api', 'rss', 'partnership'].includes(d.access_method) && d.permission_status !== 'granted') throw new AppError('permission_required', 409);
  const cats = Array.isArray(d.categories) ? d.categories : [];
  if (!cats.length || cats.some((c) => !CATEGORIES.includes(c))) throw new AppError('invalid_category');
  const official = httpsUrl(d.official_url);
  if (!official) throw new AppError('invalid_url');
  return tx(db, () => {
    db.prepare(`INSERT INTO sources(slug,name,kind,region,official_url,access_method,permission_status,terms_checked_at,tags,active)
      VALUES(?,?,?,?,?,?,?,?,?,?)
      ON CONFLICT(slug) DO UPDATE SET name=excluded.name, kind=excluded.kind, region=excluded.region, official_url=excluded.official_url,
        access_method=excluded.access_method, permission_status=excluded.permission_status, terms_checked_at=excluded.terms_checked_at,
        tags=excluded.tags, active=excluded.active`)
      .run(slug, name, d.kind, clean(d.region || 'Brussels', 60), official, d.access_method, d.permission_status,
        d.terms_checked_at || null, clean(d.tags, 300), d.active === false ? 0 : 1);
    const id = db.prepare('SELECT id FROM sources WHERE slug = ?').get(slug).id;
    db.prepare('DELETE FROM source_categories WHERE source_id = ?').run(id);
    for (const c of cats) db.prepare('INSERT INTO source_categories(source_id,category) VALUES(?,?)').run(id, c);
    audit(db, actorId, 'source.upsert', `source:${slug}`);
    return id;
  });
}

// ---------- Community listings and moderation ----------
function submitListing(db, user, input) {
  const category = clean(input.category, 20);
  if (!CATEGORIES.includes(category)) throw new AppError('invalid_category');
  const title = clean(input.title, 200);
  if (title.length < 3) throw new AppError('invalid_title');
  const r = db.prepare(`INSERT INTO listings(kind,category,title,summary,city,url,tags,status,verification,submitted_by)
    VALUES('community',?,?,?,?,?,?,'pending','none',?)`)
    .run(category, title, clean(input.summary, 2000), clean(input.city || 'Brussels', 100) || 'Brussels',
      httpsUrl(input.url), clean(input.tags, 300), user.id);
  audit(db, user.id, 'listing.submit', `listing:${r.lastInsertRowid}`);
  return Number(r.lastInsertRowid);
}

// Public search: only moderated (approved) listings. Pending, rejected and reported ones never appear.
function searchListings(db, { category, q } = {}) {
  const where = ["status = 'approved'"], p = [];
  if (category) {
    if (!CATEGORIES.includes(category)) throw new AppError('invalid_category');
    where.push('category = ?'); p.push(category);
  }
  const term = clean(q, 100).toLowerCase();
  if (term) {
    const like = `%${escLike(term)}%`;
    where.push(`(lower(title) LIKE ? ${LIKE_ESC} OR lower(summary) LIKE ? ${LIKE_ESC} OR lower(tags) LIKE ? ${LIKE_ESC})`);
    p.push(like, like, like);
  }
  return db.prepare(`SELECT id,kind,category,title,summary,city,url,verification,last_checked_at
    FROM listings WHERE ${where.join(' AND ')} ORDER BY id DESC LIMIT 50`).all(...p);
}

function listByStatus(db, actor, status) {
  assertRole(actor, ['moderator', 'admin']);
  if (!['pending', 'approved', 'rejected', 'expired', 'reported'].includes(status)) throw new AppError('invalid_status');
  return db.prepare('SELECT id,kind,category,title,summary,city,url,status,created_at FROM listings WHERE status = ? ORDER BY id LIMIT 100').all(status);
}

function moderateListing(db, moderator, id, { decision, note }) {
  assertRole(moderator, ['moderator', 'admin']);
  if (!['approve', 'reject'].includes(decision)) throw new AppError('invalid_decision');
  const r = db.prepare("UPDATE listings SET status = ?, moderation_note = ?, updated_at = datetime('now') WHERE id = ?")
    .run(decision === 'approve' ? 'approved' : 'rejected', clean(note, 500) || null, Number(id));
  if (r.changes === 0) throw new AppError('not_found', 404);
  audit(db, moderator.id, `listing.${decision}`, `listing:${id}`);
}

function reportListing(db, userId, listingId, reason) {
  const text = clean(reason, 500);
  if (text.length < 3) throw new AppError('invalid_reason');
  return tx(db, () => {
    const l = db.prepare("SELECT id FROM listings WHERE id = ? AND status = 'approved'").get(Number(listingId));
    if (!l) throw new AppError('not_found', 404);
    const r = db.prepare('INSERT INTO reports(listing_id,reporter_id,reason) VALUES(?,?,?)').run(l.id, userId ?? null, text);
    // A report hides the listing from the public until a moderator decides.
    db.prepare("UPDATE listings SET status = 'reported', updated_at = datetime('now') WHERE id = ?").run(l.id);
    return Number(r.lastInsertRowid);
  });
}

function listReports(db, actor, status = 'open') {
  assertRole(actor, ['moderator', 'admin']);
  return db.prepare(`SELECT r.id, r.reason, r.status, r.created_at, l.id AS listing_id, l.title, l.url, l.status AS listing_status
    FROM reports r JOIN listings l ON l.id = r.listing_id WHERE r.status = ? ORDER BY r.id`).all(status);
}

function resolveReport(db, moderator, reportId, { action }) {
  assertRole(moderator, ['moderator', 'admin']);
  if (!['keep', 'remove'].includes(action)) throw new AppError('invalid_action');
  return tx(db, () => {
    const rep = db.prepare("SELECT id, listing_id FROM reports WHERE id = ? AND status = 'open'").get(Number(reportId));
    if (!rep) throw new AppError('not_found', 404);
    db.prepare("UPDATE listings SET status = ?, updated_at = datetime('now') WHERE id = ?")
      .run(action === 'keep' ? 'approved' : 'rejected', rep.listing_id);
    db.prepare("UPDATE reports SET status = 'resolved', resolved_by = ?, resolved_at = datetime('now') WHERE id = ?")
      .run(moderator.id, rep.id);
    audit(db, moderator.id, `report.${action}`, `report:${rep.id}`);
  });
}

module.exports = {
  AppError, assertRole, createUser, authenticate, createSession, userFromSession, destroySession,
  saveProfile, getProfile, deleteUserData, saveItem, removeItem, listSaved,
  listDirectory, upsertSource, submitListing, searchListings, listByStatus, moderateListing,
  reportListing, listReports, resolveReport, audit, tx, escLike, LIKE_ESC,
};
