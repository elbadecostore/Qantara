'use strict';
// Pure request-guard logic. Kept free of Express so it can be tested without installing it.
const UNSAFE = new Set(['POST', 'PUT', 'PATCH', 'DELETE']);

// Normalise "https://host:443" style origins; returns null for anything that is not a plain origin.
function normalizeOrigin(value) {
  try {
    const u = new URL(String(value));
    if (u.protocol !== 'https:' && u.protocol !== 'http:') return null;
    if (u.pathname !== '/' && u.pathname !== '' || u.search || u.hash) return null;
    return `${u.protocol}//${u.host}`;
  } catch { return null; }
}

// Explicit CSRF defence for state-changing requests: the Origin header must be present and allow-listed.
// SameSite cookies and JSON bodies are defence in depth, not the primary control.
function checkOrigin(method, originHeader, allowedOrigins) {
  if (!UNSAFE.has(String(method).toUpperCase())) return { ok: true };
  if (!originHeader) return { ok: false, code: 'origin_required' };
  const o = normalizeOrigin(originHeader);
  if (!o || !allowedOrigins.includes(o)) return { ok: false, code: 'origin_not_allowed' };
  return { ok: true };
}

function parseCookies(header) {
  const out = {};
  for (const part of String(header || '').split(';')) {
    const i = part.indexOf('=');
    if (i <= 0) continue;
    try { out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim()); } catch { /* ignore malformed */ }
  }
  return out;
}

module.exports = { checkOrigin, normalizeOrigin, parseCookies, UNSAFE };
