'use strict';
// HTTP tests. Need Express: run `npm install` first. Skipped automatically otherwise.
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
let hasExpress = true;
try { require.resolve('express'); } catch { hasExpress = false; }
const skip = hasExpress ? false : 'express not installed (run npm install)';
const ORIGIN = 'http://localhost:3000';

test('HTTP: CSRF origin, auth cookie, consent, roles, reset and deletion', { skip }, async (t) => {
  const { open } = require('../src/db');
  const { createApp } = require('../src/server');
  const { load } = require('../src/config');
  const { MemoryMailer } = require('../src/mailer');
  const db = open(path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'belnova-http-')), 'h.sqlite'));
  const mailer = new MemoryMailer();
  const server = createApp({ db, cfg: load({}), provider: null, mailer }).listen(0);
  t.after(() => server.close());
  const base = `http://127.0.0.1:${server.address().port}`;
  const call = async (method, url, { body, cookie, origin = ORIGIN } = {}) => {
    const headers = { 'content-type': 'application/json' };
    if (origin) headers.origin = origin;
    if (cookie) headers.cookie = cookie;
    const r = await fetch(base + url, { method, headers, body: body ? JSON.stringify(body) : undefined });
    return { status: r.status, body: await r.json().catch(() => ({})), setCookie: r.headers.get('set-cookie') };
  };

  // CSRF
  assert.equal((await call('POST', '/api/auth/login', { body: { email: 'x@example.org', password: 'x' }, origin: null })).body.error, 'origin_required');
  assert.equal((await call('POST', '/api/auth/login', { body: { email: 'x@example.org', password: 'x' }, origin: 'https://evil.example' })).body.error, 'origin_not_allowed');
  assert.equal((await call('GET', '/api/health', { origin: null })).status, 200, 'reads need no origin');

  // Registration, cookie and session
  const reg = await call('POST', '/api/auth/register', { body: { email: 'test@example.org', password: 'a long passphrase 1' } });
  assert.equal(reg.status, 201);
  assert.match(reg.setCookie, /HttpOnly/);
  const cookie = reg.setCookie.split(';')[0];
  assert.equal((await call('GET', '/api/me', { cookie })).body.user.email, 'test@example.org');
  assert.equal(mailer.sent.length, 1, 'verification email sent');

  // Consent and validation
  assert.equal((await call('PUT', '/api/profile', { body: { skills: 'x' }, cookie })).status, 400);
  assert.equal((await call('PUT', '/api/profile', { body: { consent: true, years: 'abc' }, cookie })).body.error, 'invalid_years');
  assert.equal((await call('PUT', '/api/profile', { body: { consent: true, years: 4 }, cookie })).body.profile.years, 4);

  // Authorisation
  assert.equal((await call('GET', '/api/admin/listings', { cookie })).status, 403, 'members are not moderators');
  assert.equal((await call('GET', '/api/profile')).status, 401);

  // AI off by default, anonymous allowed
  assert.equal((await call('POST', '/api/ai/chat', { body: { message: 'I need work' } })).body.status, 'unavailable');

  // Password reset: generic response and single-use token
  assert.deepEqual((await call('POST', '/api/auth/password-reset/request', { body: { email: 'nobody@example.org' } })).body, { ok: true });
  await call('POST', '/api/auth/password-reset/request', { body: { email: 'test@example.org' } });
  const token = mailer.sent.at(-1).text.match(/#token=([A-Za-z0-9_-]+)/)[1];
  assert.equal((await call('POST', '/api/auth/password-reset/confirm', { body: { token, password: 'another long passphrase' } })).status, 200);
  assert.equal((await call('POST', '/api/auth/password-reset/confirm', { body: { token, password: 'another long passphrase' } })).body.error, 'invalid_or_expired_token');
  assert.equal((await call('GET', '/api/me', { cookie })).body.user, null, 'old session revoked after reset');

  // Login and account deletion
  const login = await call('POST', '/api/auth/login', { body: { email: 'test@example.org', password: 'another long passphrase' } });
  const cookie2 = login.setCookie.split(';')[0];
  assert.equal((await call('DELETE', '/api/account', { body: { password: 'wrong wrong wrong' }, cookie: cookie2 })).status, 403);
  assert.equal((await call('DELETE', '/api/account', { body: { password: 'another long passphrase' }, cookie: cookie2 })).status, 200);
  assert.equal((await call('POST', '/api/auth/login', { body: { email: 'test@example.org', password: 'another long passphrase' } })).status, 401);
});

// Stage 2 end-to-end flows through the real HTTP layer. Not executed in the build sandbox (no Express).
test('HTTP stage 2: browse without account, submit, moderate, report, save, free AI, delete', { skip }, async (t) => {
  const { open } = require('../src/db');
  const { createApp } = require('../src/server');
  const { load } = require('../src/config');
  const { MemoryMailer } = require('../src/mailer');
  const svc = require('../src/services');
  const seed = require('../src/seed-data');
  const db = open(path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'belnova-s2-')), 's2.sqlite'));
  for (const s of seed) svc.upsertSource(db, null, { ...s, permission_status: 'none', access_method: 'none' });
  const cfg = load({ AI_ENABLED: 'true', AI_PROVIDER: 'mock' });
  const server = createApp({ db, cfg, provider: require('../src/ai/providers').createProvider(cfg), mailer: new MemoryMailer() }).listen(0);
  t.after(() => server.close());
  const base = `http://127.0.0.1:${server.address().port}`;
  const call = async (method, url, { body, cookie, origin = ORIGIN } = {}) => {
    const headers = { 'content-type': 'application/json' };
    if (origin) headers.origin = origin;
    if (cookie) headers.cookie = cookie;
    const r = await fetch(base + url, { method, headers, body: body ? JSON.stringify(body) : undefined });
    return { status: r.status, body: await r.json().catch(() => ({})), setCookie: r.headers.get('set-cookie') };
  };

  // Browsing and the directory work with no account
  const dir = await call('GET', '/api/directory?category=work');
  assert.ok(dir.body.items.some((d) => d.name === 'Actiris' && d.verification === 'official_reference'));
  assert.equal((await call('GET', '/api/listings')).body.items.length, 0, 'nothing public before moderation');
  const home = await fetch(base + '/');
  assert.ok([200, 404].includes(home.status));

  // Free AI answers from the catalogue and returns a token; no account needed
  const chat = await call('POST', '/api/ai/chat', { body: { message: 'I need work in Brussels' } });
  assert.equal(chat.body.status, 'ok');
  assert.ok(chat.body.items.some((i) => i.name === 'Actiris'));
  assert.ok(chat.body.conversationToken);
  const chat2 = await call('POST', '/api/ai/chat', { body: { message: 'thanks', conversationToken: chat.body.conversationToken } });
  assert.equal(chat2.status, 200);
  assert.equal((await call('POST', '/api/ai/chat', { body: { message: 'x', conversationToken: 'wrong-token' } })).status, 404);

  // Member submits; it stays private until a moderator approves
  const reg = await call('POST', '/api/auth/register', { body: { email: 'member@example.org', password: 'a long passphrase 1' } });
  const cookie = reg.setCookie.split(';')[0];
  const sub = await call('POST', '/api/listings', { body: { category: 'housing', title: 'Studio calme', summary: 'Libre', url: 'https://example.org/annonce' }, cookie });
  assert.equal(sub.body.status, 'pending');
  assert.equal((await call('GET', '/api/listings?category=housing')).body.items.length, 0);
  const mod = svc.createUser(db, 'mod@example.org', 'a long passphrase 1');
  db.prepare("UPDATE users SET role = 'moderator' WHERE id = ?").run(mod.id);
  const modCookie = (await call('POST', '/api/auth/login', { body: { email: 'mod@example.org', password: 'a long passphrase 1' } })).setCookie.split(';')[0];
  assert.equal((await call('POST', `/api/admin/listings/${sub.body.id}/decision`, { body: { decision: 'approve' }, cookie: modCookie })).status, 200);
  const pub = await call('GET', '/api/listings?category=housing');
  assert.equal(pub.body.items[0].title, 'Studio calme');
  assert.equal(pub.body.items[0].verification, 'none', 'approved is not verified');

  // Anonymous report hides the listing until a moderator decides
  assert.equal((await call('POST', `/api/listings/${sub.body.id}/report`, { body: { reason: 'looks wrong' } })).status, 201);
  assert.equal((await call('GET', '/api/listings?category=housing')).body.items.length, 0);

  // Save requires login; saved items come back with names
  assert.equal((await call('POST', '/api/saved', { body: { type: 'source', id: 1 } })).status, 401);
  const src = db.prepare("SELECT id FROM sources WHERE slug = 'actiris'").get().id;
  assert.equal((await call('POST', '/api/saved', { body: { type: 'source', id: src }, cookie })).status, 201);
  assert.equal((await call('GET', '/api/saved', { cookie })).body.items[0].name, 'Actiris');

  // Account deletion removes saved items and sessions
  assert.equal((await call('DELETE', '/api/account', { body: { password: 'a long passphrase 1' }, cookie })).status, 200);
  assert.equal((await call('GET', '/api/me', { cookie })).body.user, null);
});
