'use strict';
// NOVA (BELNOVA AI) with the free test provider, and clear reasons when it is off.
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { open } = require('../src/db');
const svc = require('../src/services');
const assistant = require('../src/ai/assistant');
const { createProvider } = require('../src/ai/providers');
const { aiStatus } = require('../src/ai/status');
const { mockReply, detectLang, T } = require('../src/ai/mockReplies');
const { load } = require('../src/config');
const seed = require('../src/seed-data');

const fileDb = () => open(path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'belnova-nova-')), 'n.sqlite'));
const seeded = (db) => { for (const s of seed) svc.upsertSource(db, null, { ...s, permission_status: 'none', access_method: 'none' }); };

// 1. Startup reads .env through Node's own flag (the root cause of "AI: off")
test('every script that needs settings reads .env through --env-file-if-exists', () => {
  const pkg = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'package.json'), 'utf8'));
  for (const name of ['start', 'seed', 'admin', 'backup', 'restore', 'check-ai']) {
    assert.ok(pkg.scripts[name].includes('--env-file-if-exists=.env'), name);
  }
});

// 2. Settings: AI is off by default, and the test provider can be turned on from the environment
test('AI is off by default and the free test provider is selectable without any key', () => {
  const def = load({});
  assert.equal(def.aiEnabled, false);
  const on = load({ AI_ENABLED: 'true', AI_PROVIDER: 'mock' });
  assert.equal(on.aiEnabled, true);
  assert.equal(createProvider(on).name, 'mock');
  assert.equal(createProvider(on).paid, false);
});

// 3. Clear reasons, in the order the guard checks them
test('status explains exactly why NOVA is not ready', () => {
  const p = (cfg) => aiStatus(cfg, createProvider(cfg));
  assert.equal(p(load({})).reason, 'ai_disabled');
  assert.equal(p(load({ AI_ENABLED: 'true', AI_PROVIDER: 'anthropic' })).reason, 'ai_not_configured');
  assert.equal(p(load({ AI_ENABLED: 'true', AI_PROVIDER: 'anthropic', AI_API_KEY: 'k', AI_MODEL: 'm' })).reason, 'ai_prices_not_set');
  assert.equal(p(load({ AI_ENABLED: 'true', AI_PROVIDER: 'mock' })).reason, 'ready');
  assert.equal(p(load({ AI_ENABLED: 'true', AI_PROVIDER: 'mock' })).ready, true);
});

test('status output never contains a secret value', () => {
  const cfg = load({ AI_ENABLED: 'true', AI_PROVIDER: 'anthropic', AI_API_KEY: 'sk-test-SECRET-VALUE', AI_MODEL: 'm' });
  assert.ok(!JSON.stringify(aiStatus(cfg, createProvider(cfg))).includes('SECRET-VALUE'));
});

// 4. Multilingual test answers that do not invent anything
test('test replies are in the user language, say they are test data, and contain no link', () => {
  const samples = {
    ar: 'أبحث عن عمل وسكن في بروكسل', fr: 'Je cherche du travail et un logement à Bruxelles', es: 'Busco trabajo y vivienda en Bruselas',
    en: 'I need work and a room in Brussels', de: 'Ich suche Arbeit und eine Wohnung in Brüssel', nl: 'Ik zoek werk en een woning in Brussel',
    pt: 'Procuro emprego e moradia em Bruxelas', it: 'Cerco lavoro e una casa a Bruxelles',
  };
  for (const [lang, text] of Object.entries(samples)) {
    assert.equal(detectLang(text), lang, `detect ${lang}`);
    const reply = mockReply(text, 3);
    assert.ok(reply.startsWith(T[lang].tag), `${lang} tag`);
    assert.ok(!/https?:\/\/|www\./i.test(reply), `${lang}: no link invented`);
    assert.ok(reply.includes('3'), `${lang}: count shown`);
  }
});

test('with nothing found, the test provider says so and invents nothing', () => {
  assert.match(mockReply('Je cherche un emploi pour mon frère à Liège', 0), /Aucun élément/);
  assert.match(mockReply('hi', 0), /Hello|Hallo|Hola|Ciao|Bonjour|Olá|Hallo|مرحباً/);
});

// 5. The real request path (assistant + database + provider), without HTTP
test('NOVA answers with the free provider, grounded in database items only', async () => {
  const db = fileDb(); seeded(db);
  const cfg = load({ AI_ENABLED: 'true', AI_PROVIDER: 'mock' });
  const out = await assistant.answer({ db, cfg, provider: createProvider(cfg), message: 'Je cherche du travail à Bruxelles' });
  assert.equal(out.status, 'ok');
  assert.match(out.reply, /Mode test/);
  const names = new Set(db.prepare('SELECT name FROM sources').all().map((r) => r.name));
  assert.ok(out.items.length > 0 && out.items.every((i) => names.has(i.name)), 'every item exists in the database');
  assert.ok(out.items.every((i) => i.url === null || i.url.startsWith('https://')));
  assert.equal(db.prepare('SELECT COALESCE(SUM(cost_eur),0) s FROM ai_usage').get().s, 0);
});

test('NOVA says clearly that it is off, with the reason, and makes no call', async () => {
  const db = fileDb(); seeded(db);
  let called = false;
  const provider = { name: 'mock', model: 'm', paid: false, configured: () => true, complete: async () => { called = true; return { text: 'x', inputTokens: 1, outputTokens: 1 }; } };
  const out = await assistant.answer({ db, cfg: load({}), provider, message: 'I need work' });
  assert.equal(out.status, 'unavailable');
  assert.equal(out.code, 'ai_disabled');
  assert.equal(called, false, 'no provider call when disabled');
});

test('a failing provider is reported as unavailable, not as an invented answer', async () => {
  const db = fileDb(); seeded(db);
  const cfg = load({ AI_ENABLED: 'true', AI_PROVIDER: 'mock' });
  const broken = { name: 'mock', model: 'm', paid: false, configured: () => true, complete: async () => { throw new Error('boom'); } };
  const out = await assistant.answer({ db, cfg, provider: broken, message: 'work' });
  assert.equal(out.status, 'unavailable');
  assert.equal(out.code, 'ai_provider_error');
  assert.equal(out.reply, undefined);
});

test('conversation context is kept with the free provider across turns', async () => {
  const db = fileDb(); seeded(db);
  const cfg = load({ AI_ENABLED: 'true', AI_PROVIDER: 'mock' });
  const p = createProvider(cfg);
  const a = await assistant.answer({ db, cfg, provider: p, message: 'I need work' });
  const b = await assistant.answer({ db, cfg, provider: p, conversationToken: a.conversationToken, message: 'Brussels please' });
  assert.equal(b.status, 'ok');
  assert.equal(b.conversationToken, a.conversationToken);
  assert.equal(db.prepare('SELECT COUNT(*) n FROM ai_messages').get().n, 4);
});
