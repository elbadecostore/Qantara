'use strict';
// Static and behavioural checks for the frontend. The browser itself is not available in the build sandbox,
// so the page script runs here against a stubbed DOM and a stubbed API. This proves the client logic,
// not the real rendering in a browser.
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');

const PAGE = path.join(__dirname, '..', 'public', 'index.html');
const html = fs.existsSync(PAGE) ? fs.readFileSync(PAGE, 'utf8') : null;
const skip = html ? false : 'public/index.html missing';
const script = html ? html.match(/<script>([\s\S]*?)<\/script>/)[1] : '';

test('page contains no secrets and no sample listings', { skip }, () => {
  for (const bad of [/sk-ant/i, /api[-_]?key\s*[:=]\s*['"][A-Za-z0-9]{12,}/i, /BREVO_API_KEY\s*=/i, /AI_API_KEY\s*=/i]) assert.ok(!bad.test(html), `secret pattern ${bad}`);
  for (const fake of ['Kitchen assistant', 'Chambre en colocation', 'Cuisine solidaire', 'Warehouse assistant']) assert.ok(!html.includes(fake), fake);
  assert.ok(!/localStorage|sessionStorage/.test(script), 'no browser storage for auth tokens');
});

test('every translation key has exactly 8 non-empty entries, and every key used exists', { skip }, () => {
  const K = new Function(script.slice(script.indexOf('const K='), script.indexOf('const tr=')) + ';return K;')();
  for (const [k, v] of Object.entries(K)) assert.equal(v.length, 8, k), assert.ok(v.every((s) => String(s).trim()), k);
  const used = new Set([...script.matchAll(/tr\(\s*'([a-z_]+)'/g)].map((m) => m[1]).concat([...script.matchAll(/tr\('nav_'\+/g)].length ? ['nav_home'] : []));
  for (const k of used) if (!k.endsWith('_')) assert.ok(k in K, `missing key ${k}`); // keys ending in _ are built dynamically
  for (const k of ['err_generic', 'err_network', 'err_rate', 'err_creds', 'err_taken', 'err_invalid', 'err_consent', 'err_login', 'err_forbidden', 'err_notfound', 'err_ai']) assert.ok(K[k], k);
});

test('every API path the page calls exists on the server', { skip }, () => {
  const server = fs.readFileSync(path.join(__dirname, '..', 'src', 'server.js'), 'utf8');
  const routes = [...server.matchAll(/app\.(get|post|put|delete)\('([^']+)'/g)].map((m) => m[1].toUpperCase() + ' ' + m[2]);
  const calls = [...script.matchAll(/api\('(GET|POST|PUT|DELETE)',\s*[`'](\/api\/[^`'?$]+)/g)].map((m) => m[1] + ' ' + m[2]);
  assert.ok(calls.length >= 10, 'found page API calls');
  for (const c of calls) {
    const norm = c.replace(/\/$/, '');
    const ok = routes.some((r) => r === norm || (r.includes(':') && r.split('/:')[0] === norm.split('/')[0] + '/' + norm.split('/')[1] && r.split('/').length === norm.split('/').length) || r.startsWith(norm.replace(/\/[^/]+$/, '/')) && r.split('/').length === norm.split('/').length);
    assert.ok(ok, `no server route for ${c}`);
  }
});

test('plain data fields are never interpolated into HTML without escaping', { skip }, () => {
  // A bare ${obj.field} with a data object is the dangerous pattern. Expressions that pass through
  // esc(), safeUrl(), Number(), tr() or the escaping card builders are safe.
  const bare = [...script.matchAll(/\$\{(d|l|i|s|p|r|e)\.(\w+)\}/g)];
  const bad = bare.filter((m) => {
    const before = script.slice(Math.max(0, m.index - 6), m.index);
    return !/(esc|safeUrl|Number)\($/.test(before) && !/esc\(|safeUrl\(/.test(before);
  }).map((m) => m[0]);
  assert.deepEqual(bad, [], 'unescaped data fields: ' + bad.join(' | '));
});

// ---------- behaviour with a stubbed DOM and API ----------
function runPage(apiHandler) {
  const els = {};
  const el = (id) => els[id] || (els[id] = { id, innerHTML: '', textContent: '', value: '', placeholder: '', style: {}, children: [], classList: { _s: new Set(), toggle(c, f) { f = f === undefined ? !this._s.has(c) : f; f ? this._s.add(c) : this._s.delete(c); }, contains(c) { return this._s.has(c); } }, appendChild(c) { this.children.push(c); return c; }, focus() {}, checked: false, selectedIndex: 0, scrollTop: 0, onclick: null });
  const doc = { getElementById: (id) => el(id), createElement: () => el('tmp' + Math.random()), documentElement: {} };
  const calls = [];
  const fetchStub = async (url, opts = {}) => {
    calls.push({ url, method: opts.method || 'GET', body: opts.body ? JSON.parse(opts.body) : undefined });
    const out = await apiHandler(url, opts.method || 'GET', opts.body ? JSON.parse(opts.body) : undefined);
    if (out instanceof Error) throw out;
    return { ok: out.status < 400, status: out.status, json: async () => out.body };
  };
  const sandbox = { document: doc, fetch: fetchStub, window: { scrollTo() {} }, confirm: () => true, setTimeout: () => 0, clearTimeout() {}, console, URL, AbortSignal, Promise, JSON, Set, Map, Number, String, Object, Array, Math, Date, RegExp, Error, encodeURIComponent, Intl: undefined };
  const fn = new Function(...Object.keys(sandbox), script + '\n;return {api,lstCard,dirCard,aiSend,saveItem,errText,setLang,get ME(){return ME},set ME(v){ME=v},get AI_TOKEN(){return AI_TOKEN}, authModal, toast, get CUR(){return CUR}};');
  const page = fn(...Object.values(sandbox));
  return { page, els, calls, el };
}
const settle = () => new Promise((r) => setImmediate(r));

test('signed-out users are prompted to sign in before saving; no API call is made', { skip }, async () => {
  const { page, els, calls } = runPage(async (url) => ({ status: 200, body: { user: null, items: [] } }));
  await settle();
  const before = calls.length;
  await page.saveItem('listing', 5, null);
  assert.equal(calls.length, before, 'no POST /api/saved without login');
  assert.match(els.modalTitle.textContent, /.+/);
});

test('listing cards escape hostile titles and never link to non-https URLs', { skip }, async () => {
  const { page } = runPage(async () => ({ status: 200, body: { user: null, items: [] } }));
  await settle();
  const card = page.lstCard({ id: 1, category: 'work', title: '<img src=x onerror=alert(1)>', summary: 'ok', city: 'Brussels', url: 'javascript:alert(1)', verification: 'none' });
  assert.ok(!card.includes('<img src=x'), 'title escaped');
  assert.ok(card.includes('&lt;img'), 'escaped form present');
  assert.ok(!card.includes('javascript:'), 'javascript: URL not rendered');
  const ok = page.lstCard({ id: 2, category: 'work', title: 'A', summary: 'B', city: 'Brussels', url: 'https://www.actiris.brussels/', verification: 'none' });
  assert.ok(ok.includes('href="https://www.actiris.brussels/"'));
});

test('assistant shows only what the server returns; unavailable is shown in plain words', { skip }, async () => {
  const { page, els } = runPage(async (url, method, body) => {
    if (url === '/api/me') return { status: 200, body: { user: null } };
    if (url === '/api/ai/chat') return { status: 200, body: { status: 'unavailable', code: 'ai_disabled', items: [] } };
    return { status: 200, body: { items: [] } };
  });
  await settle();
  els.aiIn = { value: 'I need work', placeholder: '', focus() {} };
  await page.aiSend();
  const last = els.msgs ? els.msgs.children.at(-1) : null;
  assert.ok(last, 'bot bubble created');
  assert.match(last.innerHTML, /unavailable|indisponible|غير متاح|verfügbar|niet beschikbaar|indisponível|disponibile|no disponible/i);
  assert.ok(last.innerHTML.includes('ai_disabled'), 'the reason code is shown for diagnosis');
});

test('assistant keeps the conversation token and clears it when the server reports not_found', { skip }, async () => {
  let n = 0;
  const { page, els } = runPage(async (url, method, body) => {
    if (url === '/api/me') return { status: 200, body: { user: null } };
    if (url === '/api/ai/chat') {
      n++;
      if (n === 1) return { status: 200, body: { status: 'ok', conversationToken: 'TOKEN_ABC', reply: 'Hi', items: [{ type: 'source', id: 1, name: 'Actiris', city: 'Brussels', url: 'https://www.actiris.brussels/' }] } };
      if (n === 2) return { status: 404, body: { error: 'not_found' } };
    }
    return { status: 200, body: { items: [] } };
  });
  await settle();
  els.aiIn = { value: 'work', placeholder: '', focus() {} };
  await page.aiSend();
  assert.equal(page.AI_TOKEN, 'TOKEN_ABC', 'token kept after first reply');
  els.aiIn.value = 'again';
  await page.aiSend();
  assert.equal(page.AI_TOKEN, null, 'token cleared after not_found');
});

test('network failures and server codes become translated messages', { skip }, async () => {
  const { page } = runPage(async () => new Error('offline'));
  await settle();
  assert.equal(page.errText({ code: 'network' }), page.errText({ code: 'network' }));
  for (const code of ['rate_limited', 'invalid_credentials', 'email_taken', 'invalid_years', 'consent_required', 'origin_required', 'mystery_code']) {
    assert.ok(page.errText({ code }).length > 3, code);
  }
});

test('each language renders its own labels (no key falls back to a raw key name)', { skip }, async () => {
  const { page, els } = runPage(async (url) => ({ status: 200, body: { user: null, items: [] } }));
  await settle();
  for (let i = 0; i < 8; i++) {
    page.setLang(i);
    assert.ok(!/\b(err_|st_|nav_|pf_)[a-z_]+\b/.test(els.main.innerHTML), `raw key in language ${i}`);
  }
});
