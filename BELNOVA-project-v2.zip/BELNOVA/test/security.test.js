'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { open } = require('../src/db');
const svc = require('../src/services');
const accounts = require('../src/accounts');
const guards = require('../src/guards');
const { RateLimiter, SqliteStore } = require('../src/rateLimit');
const { MemoryMailer, UnconfiguredMailer } = require('../src/mailer');
const { load } = require('../src/config');
const { hashToken } = require('../src/security');
const assistant = require('../src/ai/assistant');

const PW = 'a long passphrase here';
const NEW_PW = 'another long passphrase';
const fileDb = () => open(path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'belnova-sec-')), 's.sqlite'));
const cfg = load({ APP_URL: 'https://belnova.example.org', APP_ORIGINS: 'https://app.belnova.example.org' });
// Synchronous helper: every service call under test is synchronous (only mail-sending functions are async).
const code = (fn) => { try { fn(); return null; } catch (e) { return e.code || e.message; } };
const member = (db, email = 'm@example.org') => svc.createUser(db, email, PW);
const moderator = (db) => { const u = svc.createUser(db, 'mod@example.org', PW); db.prepare("UPDATE users SET role='moderator' WHERE id=?").run(u.id); return { id: u.id, role: 'moderator' }; };

// ---------- 1. CSRF: explicit Origin check on state-changing requests ----------
test('CSRF: state-changing requests need an allow-listed Origin', () => {
  const ok = ['https://belnova.example.org', 'https://app.belnova.example.org'];
  assert.deepEqual(guards.checkOrigin('POST', 'https://belnova.example.org', ok), { ok: true });
  assert.equal(guards.checkOrigin('POST', undefined, ok).code, 'origin_required', 'missing Origin rejected');
  assert.equal(guards.checkOrigin('POST', 'https://evil.example', ok).code, 'origin_not_allowed');
  assert.equal(guards.checkOrigin('DELETE', 'https://evil.example', ok).code, 'origin_not_allowed');
  assert.equal(guards.checkOrigin('PUT', 'null', ok).code, 'origin_not_allowed', 'opaque "null" origin rejected');
  assert.equal(guards.checkOrigin('POST', 'https://belnova.example.org/path', ok).code, 'origin_not_allowed', 'origin with a path is not an origin');
  assert.equal(guards.checkOrigin('POST', 'https://belnova.example.org.evil.io', ok).code, 'origin_not_allowed', 'lookalike host rejected');
  assert.deepEqual(guards.checkOrigin('GET', 'https://evil.example', ok), { ok: true }, 'reads are not state-changing');
});

test('allowed origins are normalised from configuration (default port, trailing slash)', () => {
  assert.deepEqual(load({ APP_URL: 'https://belnova.example.org/' }).allowedOrigins, ['https://belnova.example.org']);
  assert.equal(guards.normalizeOrigin('HTTPS://Belnova.Example.org:443'), 'https://belnova.example.org');
});

test('cookie parsing ignores malformed input instead of crashing', () => {
  assert.deepEqual(guards.parseCookies('a=1; b=%E0%A4%A; c=3'), { a: '1', c: '3' });
  assert.deepEqual(guards.parseCookies(undefined), {});
});

// ---------- 2. Rate limiting shared across instances ----------
test('rate limit is enforced across two app instances that share the database', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'belnova-rl-'));
  const f = path.join(dir, 'shared.sqlite');
  const a = new RateLimiter(new SqliteStore(open(f)));
  const b = new RateLimiter(new SqliteStore(open(f)));
  const now = 5_000_000;
  assert.equal((await a.hit('login:x', 2, 60000, now)).ok, true);
  assert.equal((await b.hit('login:x', 2, 60000, now)).ok, true);
  assert.equal((await a.hit('login:x', 2, 60000, now)).ok, false, 'third attempt blocked on instance A');
  assert.equal((await b.hit('login:x', 2, 60000, now)).ok, false, 'and on instance B');
  assert.equal((await b.hit('login:x', 2, 60000, now + 60001)).ok, true, 'window resets');
});

// ---------- 3. Password reset and email verification ----------
test('password reset: unknown and known emails get the same response', async () => {
  const db = fileDb(); member(db); const mail = new MemoryMailer();
  const known = await accounts.requestPasswordReset(db, mail, cfg, 'm@example.org');
  const unknown = await accounts.requestPasswordReset(db, mail, cfg, 'nobody@example.org');
  assert.deepEqual(known, unknown);
  assert.equal(mail.sent.length, 1, 'mail only sent for the real account');
});

test('password reset: token works once, expires, and signs out every session', async () => {
  const db = fileDb(); const u = member(db); const mail = new MemoryMailer();
  const s1 = svc.createSession(db, u.id).token;
  await accounts.requestPasswordReset(db, mail, cfg, 'm@example.org');
  const link = mail.sent[0].text.match(/#token=([A-Za-z0-9_-]+)/)[1];
  assert.ok(mail.sent[0].text.startsWith('Reset your password: https://belnova.example.org/reset#token='), 'token travels in URL fragment');
  assert.equal(await code(() => accounts.resetPassword(db, link, 'short')), 'weak_password');
  accounts.resetPassword(db, link, NEW_PW);
  assert.equal(svc.userFromSession(db, s1), null, 'old sessions revoked');
  assert.equal(await code(() => accounts.resetPassword(db, link, NEW_PW)), 'invalid_or_expired_token', 'single use');
  assert.equal(svc.authenticate(db, 'm@example.org', NEW_PW).id, u.id);
  assert.equal(svc.authenticate(db, 'm@example.org', PW), null, 'old password dead');
});

test('password reset: expired tokens are rejected and only hashes are stored', async () => {
  const db = fileDb(); const u = member(db); const mail = new MemoryMailer();
  await accounts.requestPasswordReset(db, mail, cfg, 'm@example.org');
  const raw = mail.sent[0].text.match(/#token=([A-Za-z0-9_-]+)/)[1];
  assert.ok(!db.prepare('SELECT token_hash FROM auth_tokens').all().map((r) => r.token_hash).includes(raw));
  assert.ok(db.prepare('SELECT token_hash FROM auth_tokens').all().map((r) => r.token_hash).includes(hashToken(raw)));
  db.prepare("UPDATE auth_tokens SET expires_at = '2000-01-01 00:00:00' WHERE user_id = ?").run(u.id);
  assert.equal(await code(() => accounts.resetPassword(db, raw, NEW_PW)), 'invalid_or_expired_token');
});

test('password reset: requesting again invalidates the previous link', async () => {
  const db = fileDb(); member(db); const mail = new MemoryMailer();
  await accounts.requestPasswordReset(db, mail, cfg, 'm@example.org');
  const first = mail.sent[0].text.match(/#token=([A-Za-z0-9_-]+)/)[1];
  await accounts.requestPasswordReset(db, mail, cfg, 'm@example.org');
  assert.equal(await code(() => accounts.resetPassword(db, first, NEW_PW)), 'invalid_or_expired_token');
});

test('email verification: confirms once, rejects reuse and garbage', async () => {
  const db = fileDb(); const u = member(db); const mail = new MemoryMailer();
  await accounts.sendVerificationEmail(db, mail, cfg, { id: u.id, email: u.email });
  const raw = mail.sent[0].text.match(/#token=([A-Za-z0-9_-]+)/)[1];
  assert.equal(await code(() => accounts.confirmEmail(db, 'not-a-real-token')), 'invalid_or_expired_token');
  accounts.confirmEmail(db, raw);
  assert.ok(db.prepare('SELECT email_verified_at v FROM users WHERE id = ?').get(u.id).v);
  assert.equal(await code(() => accounts.confirmEmail(db, raw)), 'invalid_or_expired_token');
});

test('reset and verification tokens cannot be used for each other', async () => {
  const db = fileDb(); const u = member(db); const mail = new MemoryMailer();
  await accounts.sendVerificationEmail(db, mail, cfg, { id: u.id, email: u.email });
  const verifyToken = mail.sent[0].text.match(/#token=([A-Za-z0-9_-]+)/)[1];
  assert.equal(await code(() => accounts.resetPassword(db, verifyToken, NEW_PW)), 'invalid_or_expired_token');
});

test('without a mail provider, reset requests fail visibly for the operator but the API stays generic', async () => {
  const db = fileDb(); member(db);
  const res = await accounts.requestPasswordReset(db, new UnconfiguredMailer(), cfg, 'm@example.org');
  assert.deepEqual(res, { ok: true });
  assert.equal(db.prepare("SELECT COUNT(*) n FROM audit_log WHERE action = 'password_reset.mail_failed'").get().n, 1);
});

// ---------- 4. Sessions and password change ----------
test('logout ends the session; changing the password signs out all other sessions', () => {
  const db = fileDb(); const u = member(db);
  const a = svc.createSession(db, u.id).token;
  const b = svc.createSession(db, u.id).token;
  svc.destroySession(db, a);
  assert.equal(svc.userFromSession(db, a), null);
  assert.ok(svc.userFromSession(db, b));
  accounts.changePassword(db, u.id, PW, NEW_PW);
  assert.equal(svc.userFromSession(db, b), null, 'other session revoked');
});

test('password change requires the current password', () => {
  const db = fileDb(); const u = member(db);
  assert.equal(code(() => accounts.changePassword(db, u.id, 'wrong wrong wrong', NEW_PW)) !== null, true);
  assert.equal(svc.authenticate(db, 'm@example.org', PW).id, u.id, 'password unchanged');
});

test('disabling an account revokes access immediately', () => {
  const db = fileDb(); const u = member(db); const t = svc.createSession(db, u.id).token;
  db.prepare('UPDATE users SET disabled = 1 WHERE id = ?').run(u.id);
  assert.equal(svc.userFromSession(db, t), null);
});

// ---------- 5. Privilege escalation ----------
test('members cannot moderate, read reports, or administer sources even by calling services directly', async () => {
  const db = fileDb(); const m = member(db);
  const id = svc.submitListing(db, m, { category: 'work', title: 'Offre test' });
  const actor = { id: m.id, role: 'user' };
  assert.equal(code(() => svc.moderateListing(db, actor, id, { decision: 'approve' })), 'forbidden');
  assert.equal(code(() => svc.listByStatus(db, actor, 'pending')), 'forbidden');
  assert.equal(code(() => svc.listReports(db, actor)), 'forbidden');
  assert.equal(code(() => svc.upsertSource(db, actor, { slug: 'x-test', name: 'X', kind: 'public_body', official_url: 'https://x.example/', categories: ['work'] })), 'forbidden');
  assert.equal(db.prepare('SELECT status FROM listings WHERE id = ?').get(id).status, 'pending', 'nothing changed');
});

test('moderators can moderate but cannot change sources (admin only)', () => {
  const db = fileDb(); const mod = moderator(db); const m = member(db);
  const id = svc.submitListing(db, m, { category: 'work', title: 'Offre test' });
  svc.moderateListing(db, mod, id, { decision: 'approve' });
  assert.equal(code(() => svc.upsertSource(db, mod, { slug: 'x-test', name: 'X', kind: 'public_body', official_url: 'https://x.example/', categories: ['work'] })), 'forbidden');
});

// ---------- 6. Invalid input ----------
test('invalid input is rejected with specific codes, never stored', async () => {
  const db = fileDb(); const u = member(db);
  assert.equal(code(() => svc.saveProfile(db, u.id, { consent: true, years: 'abc' })), 'invalid_years');
  assert.equal(code(() => svc.saveProfile(db, u.id, { consent: true, years: 4.5 })), 'invalid_years');
  assert.equal(code(() => svc.saveProfile(db, u.id, { consent: true, housing_budget_eur: -5 })), 'invalid_budget');
  assert.equal(code(() => svc.saveProfile(db, u.id, { consent: true, employment: 'x' })), 'invalid_employment');
  assert.equal(code(() => svc.submitListing(db, u, { category: 'work', title: 'Job', url: 'javascript:alert(1)' })), 'invalid_url');
  assert.equal(code(() => svc.submitListing(db, u, { category: 'work', title: 'Job', url: 'https://x.example/%0a' })) , null, 'encoded control chars are text, not headers');
  assert.equal(code(() => svc.createUser(db, 'not an email', PW)), 'invalid_email');
  assert.equal(code(() => svc.createUser(db, 'x@example.org', 12345678901234)), 'weak_password');
  assert.equal(code(() => svc.reportListing(db, null, 999, 'x')), 'invalid_reason');
});

test('control characters are stripped from stored text', () => {
  const db = fileDb(); const u = member(db);
  const id = svc.submitListing(db, u, { category: 'work', title: 'Bad\u0000title\u0007here' });
  assert.equal(db.prepare('SELECT title FROM listings WHERE id = ?').get(id).title, 'Bad title here');
});

test('stored text is kept as plain text (escaping happens on output in the frontend)', () => {
  const db = fileDb(); const u = member(db);
  const id = svc.submitListing(db, u, { category: 'work', title: '<img src=x onerror=alert(1)>' });
  svc.moderateListing(db, moderator(db), id, { decision: 'approve' });
  assert.equal(svc.searchListings(db, { category: 'work' })[0].title, '<img src=x onerror=alert(1)>');
});

// ---------- 7. Account deletion ----------
test('account deletion requires the password and deletes nothing otherwise', () => {
  const db = fileDb(); const u = member(db);
  svc.saveProfile(db, u.id, { consent: true, skills: 'x' });
  assert.equal(code(() => accounts.deleteAccount(db, u.id, 'wrong wrong wrong')), 'invalid_credentials');
  assert.ok(svc.getProfile(db, u.id));
});

test('account deletion removes profile, saved items, sessions, tokens, conversations and submitted listings', async () => {
  const db = fileDb(); const u = member(db); const other = member(db, 'other@example.org');
  for (const s of require('../src/seed-data')) svc.upsertSource(db, null, { ...s, permission_status: 'none', access_method: 'none' });
  const mod = moderator(db);
  const mine = svc.submitListing(db, u, { category: 'housing', title: 'Ma chambre' });
  svc.moderateListing(db, mod, mine, { decision: 'approve' });
  const theirs = svc.submitListing(db, other, { category: 'work', title: 'Leur offre' });
  svc.moderateListing(db, mod, theirs, { decision: 'approve' });
  svc.saveProfile(db, u.id, { consent: true, skills: 'painting' });
  svc.saveItem(db, u.id, 'listing', mine);
  svc.saveItem(db, u.id, 'source', db.prepare('SELECT id FROM sources LIMIT 1').get().id);
  const sess = svc.createSession(db, u.id).token;
  await accounts.requestPasswordReset(db, new MemoryMailer(), cfg, 'm@example.org');
  const conv = await assistant.answer({ db, cfg: load({}), provider: null, user: u, message: 'work' });
  svc.reportListing(db, u.id, theirs, 'spam');
  svc.reportListing(db, other.id, mine, 'duplicate listing'); // after saving, which needs an approved listing
  void conv;

  accounts.deleteAccount(db, u.id, PW);

  assert.equal(svc.authenticate(db, 'm@example.org', PW), null, 'cannot log in');
  assert.equal(svc.userFromSession(db, sess), null, 'sessions gone');
  assert.equal(db.prepare('SELECT COUNT(*) n FROM users WHERE id = ?').get(u.id).n, 0);
  assert.equal(db.prepare('SELECT COUNT(*) n FROM profiles WHERE user_id = ?').get(u.id).n, 0);
  assert.equal(db.prepare('SELECT COUNT(*) n FROM saved_items WHERE user_id = ?').get(u.id).n, 0);
  assert.equal(db.prepare('SELECT COUNT(*) n FROM auth_tokens WHERE user_id = ?').get(u.id).n, 0);
  assert.equal(db.prepare('SELECT COUNT(*) n FROM ai_conversations WHERE user_id = ?').get(u.id).n, 0);
  assert.equal(db.prepare('SELECT COUNT(*) n FROM listings WHERE id = ?').get(mine).n, 0, 'own listing removed');
  assert.equal(db.prepare('SELECT COUNT(*) n FROM saved_items WHERE item_type = ? AND item_id = ?').get('listing', mine).n, 0, 'others saved pointers cleaned');
  assert.equal(db.prepare('SELECT COUNT(*) n FROM listings WHERE id = ?').get(theirs).n, 1, 'other users content untouched');
  assert.equal(db.prepare('SELECT COUNT(*) n FROM reports WHERE listing_id = ?').get(theirs).n, 1, 'report on other content kept');
  assert.equal(db.prepare('SELECT COUNT(*) n FROM audit_log WHERE actor_id = ?').get(u.id).n, 0, 'audit trail anonymised');
  assert.equal(db.prepare("SELECT COUNT(*) n FROM audit_log WHERE action = 'user.deleted'").get().n, 1);
});

// ---------- 8. Anonymous conversations ----------
test('anonymous conversation tokens are random: no sequential ids are exposed or accepted', async () => {
  const db = fileDb(); seeded(db);
  const p = { name: 'fake', model: 'm', configured: () => true, complete: async () => ({ text: 'ok', inputTokens: 10, outputTokens: 10 }) };
  const aiCfg = { ...load({}), aiEnabled: true, aiApiKey: 'k', aiModel: 'm', monthlyLimitEur: 10, priceInPerMTok: 3, priceOutPerMTok: 15 };
  const a = await assistant.answer({ db, cfg: aiCfg, provider: p, message: 'work' });
  const b = await assistant.answer({ db, cfg: aiCfg, provider: p, message: 'work' });
  assert.notEqual(a.conversationToken, b.conversationToken);
  assert.equal(a.conversationId, undefined, 'internal id not returned');
  await assert.rejects(() => assistant.answer({ db, cfg: aiCfg, provider: p, conversationToken: String(a.conversationToken.length), message: 'x' }), { code: 'not_found' });
});

function seeded(db) { for (const s of require('../src/seed-data')) svc.upsertSource(db, null, { ...s, permission_status: 'none', access_method: 'none' }); }

// ---------- 9. Configuration safety ----------
test('production defaults: cookies secure, AI off, mail unconfigured, no paid calls possible', () => {
  const c = load({ NODE_ENV: 'production' });
  assert.equal(c.cookieSecure, true);
  assert.equal(c.aiEnabled, false);
  assert.equal(c.mailProvider, 'none');
  assert.equal(c.monthlyLimitEur, 0);
});
