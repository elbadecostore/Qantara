'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { open } = require('../src/db');
const svc = require('../src/services');
const budget = require('../src/ai/budget');
const assistant = require('../src/ai/assistant');
const { RateLimiter } = require('../src/rateLimit');
const { load } = require('../src/config');
const seed = require('../src/seed-data');
const { hashPassword, verifyPassword, hashToken } = require('../src/security');

const freshDb = () => open(path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'belnova-')), 't.sqlite'));
const PW = 'correct horse battery';
const code = (fn) => { try { fn(); return null; } catch (e) { return e.code || e.message; } };
const msg = (fn) => { try { fn(); return ''; } catch (e) { return e.message; } };
const seeded = (db) => { for (const s of seed) svc.upsertSource(db, null, { ...s, permission_status: 'none', access_method: 'none' }); };
const cfgOn = (o = {}) => ({ ...load({}), aiEnabled: true, aiApiKey: 'k', aiModel: 'm', monthlyLimitEur: 10, priceInPerMTok: 3, priceOutPerMTok: 15, aiMaxOutputTokens: 500, dailyLimitGlobal: 200, dailyLimitPerUser: 20, ...o });
const fakeProvider = (reply = 'ok', calls = []) => ({
  name: 'fake', model: 'm', configured: () => true,
  async complete(args) { calls.push(args); return { text: reply, inputTokens: 1000, outputTokens: 200 }; },
});

// ---- schema ----
test('migrations apply once and are idempotent on reopen', () => {
  const f = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'belnova-')), 'm.sqlite');
  open(f); const db = open(f);
  assert.equal(db.prepare('SELECT COUNT(*) n FROM schema_migrations').get().n, 2);
});

test('database rejects invalid roles, statuses and non-https links', () => {
  const db = freshDb();
  assert.match(msg(() => db.prepare("INSERT INTO users(email,password_hash,role) VALUES('a@b.co','x','superuser')").run()), /CHECK/);
  assert.match(msg(() => db.prepare("INSERT INTO listings(kind,category,title,status,url) VALUES('community','work','Test job','bogus',NULL)").run()), /CHECK/);
  assert.match(msg(() => db.prepare("INSERT INTO listings(kind,category,title,url) VALUES('community','work','Test job','http://x.be')").run()), /CHECK/);
});

// ---- passwords and sessions ----
test('passwords are hashed, verified, and never stored in clear', () => {
  const h = hashPassword(PW);
  assert.ok(!h.includes(PW));
  assert.equal(verifyPassword(PW, h), true);
  assert.equal(verifyPassword('wrong password here', h), false);
});

test('account creation enforces email and password rules and blocks duplicates', () => {
  const db = freshDb();
  assert.equal(code(() => svc.createUser(db, 'not-an-email', PW)), 'invalid_email');
  assert.equal(code(() => svc.createUser(db, 'a@b.co', 'short')), 'weak_password');
  svc.createUser(db, 'Amina@Example.org', PW);
  assert.equal(code(() => svc.createUser(db, 'amina@example.org', PW)), 'email_taken');
  assert.equal(svc.authenticate(db, 'AMINA@example.org', PW).role, 'user');
  assert.equal(svc.authenticate(db, 'amina@example.org', 'nope nope nope'), null);
});

test('sessions store only a hash, work, expire, and end on logout', () => {
  const db = freshDb();
  const u = svc.createUser(db, 'a@b.co', PW);
  const { token } = svc.createSession(db, u.id);
  const stored = db.prepare('SELECT token_hash FROM sessions').all().map((r) => r.token_hash);
  assert.ok(!stored.includes(token)); assert.ok(stored.includes(hashToken(token)));
  assert.equal(svc.userFromSession(db, token).id, u.id);
  db.prepare("UPDATE sessions SET expires_at = '2000-01-01 00:00:00'").run();
  assert.equal(svc.userFromSession(db, token), null);
  const t2 = svc.createSession(db, u.id).token; svc.destroySession(db, t2);
  assert.equal(svc.userFromSession(db, t2), null);
});

test('disabled accounts cannot log in or use existing sessions', () => {
  const db = freshDb();
  const u = svc.createUser(db, 'a@b.co', PW);
  const { token } = svc.createSession(db, u.id);
  db.prepare('UPDATE users SET disabled = 1').run();
  assert.equal(svc.authenticate(db, 'a@b.co', PW), null);
  assert.equal(svc.userFromSession(db, token), null);
});

// ---- consent and profiles ----
test('profile cannot be saved without consent; valid profile is stored; deletion removes it', () => {
  const db = freshDb();
  const u = svc.createUser(db, 'a@b.co', PW);
  assert.equal(code(() => svc.saveProfile(db, u.id, { skills: 'painting' })), 'consent_required');
  assert.equal(code(() => svc.saveProfile(db, u.id, { consent: true, years: 99 })), 'invalid_years');
  const p = svc.saveProfile(db, u.id, { consent: true, skills: 'construction, painting', years: 4, languages: 'ar', employment: 'a', housing_budget_eur: 600 });
  assert.equal(p.years, 4); assert.equal(p.housing_budget_eur, 600);
  svc.deleteUserData(db, u.id);
  assert.equal(svc.getProfile(db, u.id), null);
});

test('deleting account data also removes saved items and AI conversations', () => {
  const db = freshDb(); seeded(db);
  const u = svc.createUser(db, 'a@b.co', PW);
  const sid = db.prepare('SELECT id FROM sources LIMIT 1').get().id;
  svc.saveItem(db, u.id, 'source', sid);
  db.prepare('INSERT INTO ai_conversations(user_id) VALUES(?)').run(u.id);
  svc.deleteUserData(db, u.id);
  assert.equal(db.prepare('SELECT COUNT(*) n FROM saved_items').get().n, 0);
  assert.equal(db.prepare('SELECT COUNT(*) n FROM ai_conversations').get().n, 0);
});

// ---- directory ----
test('directory shows only official references, filtered by category, never as verified listings', () => {
  const db = freshDb(); seeded(db);
  const work = svc.listDirectory(db, { category: 'work' }).map((s) => s.name);
  assert.ok(work.includes('Actiris') && work.includes('VDAB'));
  assert.ok(!work.includes('Doucheflux'));
  assert.ok(svc.listDirectory(db, { category: 'work' }).every((s) => s.verification === 'official_reference' && s.access_method === 'none'));
  assert.equal(code(() => svc.listDirectory(db, { category: 'nope' })), 'invalid_category');
});

test('automated import cannot be enabled without granted permission', () => {
  const db = freshDb();
  const base = { slug: 'actiris', name: 'Actiris', kind: 'public_body', official_url: 'https://www.actiris.brussels/', categories: ['work'] };
  assert.equal(code(() => svc.upsertSource(db, null, { ...base, access_method: 'api', permission_status: 'none' })), 'permission_required');
  assert.equal(code(() => svc.upsertSource(db, null, { ...base, access_method: 'api', permission_status: 'granted' })), null);
});

// ---- listings and moderation ----
test('community submissions stay private until a moderator approves them', () => {
  const db = freshDb();
  const u = svc.createUser(db, 'a@b.co', PW);
  const mod = { id: 1, role: 'moderator' };
  const id = svc.submitListing(db, u, { category: 'housing', title: 'Chambre calme', summary: 'Près du métro', url: 'https://example.org/x' });
  assert.equal(svc.searchListings(db, { category: 'housing' }).length, 0, 'pending must not be public');
  svc.moderateListing(db, { id: 99, role: 'moderator' }, id, { decision: 'approve' });
  assert.equal(svc.searchListings(db, { category: 'housing' })[0].title, 'Chambre calme');
  assert.equal(svc.searchListings(db, { category: 'housing' })[0].verification, 'none', 'approval is not verification');
  void mod;
});

test('submissions reject http links and bad categories', () => {
  const db = freshDb(); const u = svc.createUser(db, 'a@b.co', PW);
  assert.equal(code(() => svc.submitListing(db, u, { category: 'work', title: 'Job', url: 'http://x.be' })), 'invalid_url');
  assert.equal(code(() => svc.submitListing(db, u, { category: 'casino', title: 'Job' })), 'invalid_category');
});

test('search treats LIKE wildcards as text, not patterns', () => {
  const db = freshDb(); const u = svc.createUser(db, 'a@b.co', PW);
  const id = svc.submitListing(db, u, { category: 'work', title: '100% sûr' });
  svc.moderateListing(db, { id: 1, role: 'moderator' }, id, { decision: 'approve' });
  assert.equal(svc.searchListings(db, { q: '%' }).length, 1);
  assert.equal(svc.searchListings(db, { q: 'zzz' }).length, 0);
});

test('a report hides the listing; keeping it restores, removing it rejects it', () => {
  const db = freshDb(); const u = svc.createUser(db, 'a@b.co', PW);
  const id = svc.submitListing(db, u, { category: 'work', title: 'Job offer' });
  svc.moderateListing(db, { id: 1, role: 'moderator' }, id, { decision: 'approve' });
  const rid = svc.reportListing(db, null, id, 'looks like a scam');
  assert.equal(svc.searchListings(db, { category: 'work' }).length, 0, 'reported listing hidden');
  svc.resolveReport(db, { id: 1, role: 'moderator' }, rid, { action: 'keep' });
  assert.equal(svc.searchListings(db, { category: 'work' }).length, 1, 'kept listing visible again');
  const rid2 = svc.reportListing(db, u.id, id, 'duplicate');
  svc.resolveReport(db, { id: 1, role: 'moderator' }, rid2, { action: 'remove' });
  assert.equal(db.prepare('SELECT status FROM listings WHERE id = ?').get(id).status, 'rejected');
});

test('saving requires an existing public item', () => {
  const db = freshDb(); const u = svc.createUser(db, 'a@b.co', PW);
  const id = svc.submitListing(db, u, { category: 'work', title: 'Pending job' });
  assert.equal(code(() => svc.saveItem(db, u.id, 'listing', id)), 'not_found');
  svc.moderateListing(db, { id: 1, role: 'moderator' }, id, { decision: 'approve' });
  svc.saveItem(db, u.id, 'listing', id);
  assert.equal(svc.listSaved(db, u.id).length, 1);
  svc.removeItem(db, u.id, 'listing', id);
  assert.equal(svc.listSaved(db, u.id).length, 0);
});

// ---- AI budget and assistant ----
test('AI stays off without explicit configuration (fail closed)', () => {
  const db = freshDb();
  const defaults = load({});
  assert.equal(budget.gate(db, defaults, fakeProvider(), {}).reason, 'ai_disabled');
  assert.equal(budget.gate(db, { ...defaults, aiEnabled: true }, null, {}).reason, 'ai_not_configured');
  assert.equal(budget.gate(db, { ...cfgOn(), priceInPerMTok: 0 }, fakeProvider(), {}).reason, 'ai_prices_not_set');
  assert.equal(budget.gate(db, { ...cfgOn(), monthlyLimitEur: 0 }, fakeProvider(), {}).reason, 'ai_limit_not_set');
});

test('monthly spending cap blocks a call that would exceed it', () => {
  const db = freshDb();
  assert.equal(budget.gate(db, cfgOn({ monthlyLimitEur: 0.001 }), fakeProvider(), { inputTokens: 1000 }).reason, 'ai_monthly_limit');
  assert.equal(budget.gate(db, cfgOn({ monthlyLimitEur: 10 }), fakeProvider(), { inputTokens: 1000 }).ok, true);
});

test('per-user and global daily limits are enforced', () => {
  const db = freshDb(); const u = svc.createUser(db, 'a@b.co', PW);
  const cfg = cfgOn({ dailyLimitPerUser: 2 });
  for (let i = 0; i < 2; i++) budget.record(db, cfg, fakeProvider(), { userId: u.id, inputTokens: 10, outputTokens: 10 });
  assert.equal(budget.gate(db, cfg, fakeProvider(), { userId: u.id }).reason, 'ai_user_daily_limit');
  assert.equal(budget.gate(db, cfgOn({ dailyLimitGlobal: 2 }), fakeProvider(), {}).reason, 'ai_daily_limit');
});

test('cost is computed from configured prices and recorded per call', () => {
  const db = freshDb();
  const cost = budget.record(db, cfgOn(), fakeProvider(), { inputTokens: 1000, outputTokens: 200 });
  assert.equal(Math.round(cost * 1e6), 6000); // (1000*3 + 200*15) / 1e6 EUR
  assert.equal(budget.monthlyReport(db, cfgOn()).callsToday, 1);
});

test('assistant combines work and housing needs and answers only from the catalogue', async () => {
  const db = freshDb(); seeded(db);
  const calls = [];
  const out = await assistant.answer({ db, cfg: cfgOn(), provider: fakeProvider('Here are two options.', calls), message: 'I am new to Brussels. I need a job and an affordable room.' });
  assert.equal(out.status, 'ok');
  const names = out.items.map((i) => i.name);
  assert.ok(names.includes('Actiris'), 'work source found');
  assert.ok(names.some((n) => ['Immoweb', 'Immovlan', 'HousingAnywhere'].includes(n)), 'housing source found');
  const sent = calls[0].messages.at(-1).content;
  assert.ok(sent.includes('https://www.actiris.brussels/'), 'catalogue passed to provider');
  assert.ok(calls[0].system.includes('Recommend ONLY items from the Catalogue'));
  assert.equal(db.prepare('SELECT COUNT(*) n FROM ai_usage').get().n, 1);
});

test('assistant keeps conversation context across turns; tokens are unguessable and owner-scoped', async () => {
  const db = freshDb(); seeded(db);
  const calls = [];
  const p = fakeProvider('ok', calls);
  const a = await assistant.answer({ db, cfg: cfgOn(), provider: p, message: 'I need work' });
  assert.match(a.conversationToken, /^[A-Za-z0-9_-]{32,}$/, 'token is long and URL-safe');
  await assistant.answer({ db, cfg: cfgOn(), provider: p, conversationToken: a.conversationToken, message: 'Full-time please' });
  assert.deepEqual(calls[1].messages.map((m) => m.role), ['user', 'assistant', 'user'], 'previous turns are sent back');
  // Only the hash is stored, never the token itself.
  const stored = db.prepare('SELECT token_hash FROM ai_conversations').all().map((r) => r.token_hash);
  assert.ok(!stored.includes(a.conversationToken));
  // Numeric guessing does not work.
  await assert.rejects(() => assistant.answer({ db, cfg: cfgOn(), provider: p, conversationToken: '1', message: 'x' }), { code: 'not_found' });
  // A signed-in user's conversation cannot be opened by someone else.
  const owner = svc.createUser(db, 'owner@example.org', PW);
  const other = svc.createUser(db, 'other@example.org', PW);
  const b = await assistant.answer({ db, cfg: cfgOn(), provider: p, user: owner, message: 'hello' });
  await assert.rejects(() => assistant.answer({ db, cfg: cfgOn(), provider: p, user: other, conversationToken: b.conversationToken, message: 'x' }), { code: 'not_found' });
  await assert.rejects(() => assistant.answer({ db, cfg: cfgOn(), provider: p, user: null, conversationToken: b.conversationToken, message: 'x' }), { code: 'not_found' });
});

test('assistant reports a clear unavailable status instead of inventing answers', async () => {
  const db = freshDb(); seeded(db);
  const out = await assistant.answer({ db, cfg: load({}), provider: null, message: 'I need work' });
  assert.equal(out.status, 'unavailable');
  assert.equal(out.code, 'ai_disabled');
  assert.equal(out.reply, undefined);
});

test('a provider failure returns unavailable and records no spend', async () => {
  const db = freshDb(); seeded(db);
  const broken = { ...fakeProvider(), complete: async () => { throw new Error('provider_http_500'); } };
  const out = await assistant.answer({ db, cfg: cfgOn(), provider: broken, message: 'I need work' });
  assert.equal(out.code, 'ai_provider_error');
  assert.equal(db.prepare('SELECT COUNT(*) n FROM ai_usage').get().n, 0);
});

// ---- rate limiter and config ----
test('rate limiter blocks after the limit and resets after the window (memory store)', async () => {
  const rl = new RateLimiter();
  const t0 = 1_000_000;
  assert.equal((await rl.hit('k', 2, 1000, t0)).ok, true);
  assert.equal((await rl.hit('k', 2, 1000, t0)).ok, true);
  assert.equal((await rl.hit('k', 2, 1000, t0)).ok, false);
  assert.equal((await rl.hit('k', 2, 1000, t0 + 1001)).ok, true);
});

test('configuration defaults keep AI disabled and cookies secure in production', () => {
  const c = load({});
  assert.equal(c.aiEnabled, false);
  assert.equal(c.monthlyLimitEur, 0);
  assert.equal(load({ NODE_ENV: 'production' }).cookieSecure, true);
});
