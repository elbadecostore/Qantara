'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { open } = require('../src/db');
const svc = require('../src/services');
const { backup, restore, verify } = require('../src/backup');
const seed = require('../src/seed-data');

const tmp = () => fs.mkdtempSync(path.join(os.tmpdir(), 'belnova-bk-'));
const count = (db, t) => db.prepare(`SELECT COUNT(*) n FROM ${t}`).get().n;

test('backup is consistent and restore brings back the same data (tested end to end)', () => {
  const dir = tmp();
  const live = open(path.join(dir, 'live.sqlite'));
  for (const s of seed) svc.upsertSource(live, null, { ...s, permission_status: 'none', access_method: 'none' });
  const u = svc.createUser(live, 'backup@example.org', 'a long passphrase here');
  svc.saveProfile(live, u.id, { consent: true, skills: 'painting', years: 4 });
  const id = svc.submitListing(live, u, { category: 'work', title: 'Peintre demandé' });
  svc.moderateListing(live, { id: 1, role: 'moderator' }, id, { decision: 'approve' });
  const before = { sources: count(live, 'sources'), users: count(live, 'users'), profiles: count(live, 'profiles'), listings: count(live, 'listings') };

  const file = backup(live, path.join(dir, 'b', 'copy.sqlite'));
  assert.equal(verify(file).ok, true);

  const target = path.join(dir, 'restored', 'belnova.sqlite');
  const r = restore(file, target);
  assert.ok(r.migrations >= 2, 'migrations preserved');
  const restored = open(target);
  assert.deepEqual({ sources: count(restored, 'sources'), users: count(restored, 'users'), profiles: count(restored, 'profiles'), listings: count(restored, 'listings') }, before);
  assert.equal(svc.authenticate(restored, 'backup@example.org', 'a long passphrase here').id, u.id, 'login works after restore');
  assert.equal(svc.searchListings(restored, { category: 'work' })[0].title, 'Peintre demandé');
});

test('backup refuses to overwrite and restore refuses an existing target without force', () => {
  const dir = tmp();
  const db = open(path.join(dir, 'a.sqlite'));
  const dest = path.join(dir, 'x.sqlite');
  backup(db, dest);
  assert.throws(() => backup(db, dest), /backup_target_exists/);
  const existing = path.join(dir, 'existing.sqlite');
  fs.writeFileSync(existing, 'keep me');
  assert.throws(() => restore(dest, existing), /target_exists_use_force/);
  assert.equal(fs.readFileSync(existing, 'utf8'), 'keep me', 'existing data untouched');
  restore(dest, existing, { force: true });
});

test('verify rejects files that are not BELNOVA databases or are corrupt', () => {
  const dir = tmp();
  const junk = path.join(dir, 'junk.sqlite');
  fs.writeFileSync(junk, 'this is not sqlite at all, just text padding '.repeat(200));
  assert.throws(() => verify(junk));
  const { DatabaseSync } = require('node:sqlite');
  const other = path.join(dir, 'other.sqlite');
  const d = new DatabaseSync(other); d.exec('CREATE TABLE t(a)'); d.close();
  assert.throws(() => verify(other), /not_a_belnova_database/);
});
