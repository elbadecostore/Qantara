'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { open } = require('../src/db');
const svc = require('../src/services');
const accounts = require('../src/accounts');
const assistant = require('../src/ai/assistant');
const { createProvider } = require('../src/ai/providers');
const { BrevoMailer, createMailer, MemoryMailer } = require('../src/mailer');
const { load } = require('../src/config');
const seed = require('../src/seed-data');

const PW = 'a long passphrase here';
const fileDb = () => open(path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'belnova-p2-')), 'p.sqlite'));
const mod = (db) => { const u = svc.createUser(db, 'mod@example.org', PW); db.prepare("UPDATE users SET role='moderator' WHERE id=?").run(u.id); return { id: u.id, role: 'moderator' }; };
const seeded = (db) => { for (const s of seed) svc.upsertSource(db, null, { ...s, permission_status: 'none', access_method: 'none' }); };

// ---------- A. Account deletion: default vs explicit anonymous retention ----------
test('scrubber removes e-mails, phone numbers and personal social links, keeps normal text', () => {
  const t = accounts.scrubIdentifiers('Contactez Amina amina@mail.be ou +32 470 12 34 56, sur https://instagram.com/amina chambre 2 pièces');
  assert.ok(!t.includes('amina@mail.be'));
  assert.ok(!t.includes('470 12 34 56'));
  assert.ok(!t.includes('instagram.com/amina'));
  assert.ok(t.includes('chambre 2 pièces'));
  assert.ok(accounts.scrubIdentifiers('Site: https://www.actiris.brussels/fr').includes('https://www.actiris.brussels/fr'), 'public institutional links kept');
});

test('opt-in retention: approved submissions survive without owner, scrubbed; others are deleted', () => {
  const db = fileDb(); const m = mod(db);
  const u = svc.createUser(db, 'me@example.org', PW);
  const keep = svc.submitListing(db, u, { category: 'housing', title: 'Studio — mail me@x.be', summary: 'Libre dès mars. Appeler +32 470 11 22 33' });
  svc.moderateListing(db, m, keep, { decision: 'approve' });
  const gone = svc.submitListing(db, u, { category: 'work', title: 'Pending job' });
  accounts.deleteAccount(db, u.id, PW, { keepContributionsAnonymously: true });
  const row = db.prepare('SELECT title, summary, submitted_by, status FROM listings WHERE id = ?').get(keep);
  assert.ok(row, 'approved listing kept');
  assert.equal(row.submitted_by, null, 'no owner stored');
  assert.ok(!row.title.includes('me@x.be') && !row.summary.includes('470 11 22 33'), 'identifiers scrubbed');
  assert.equal(db.prepare('SELECT COUNT(*) n FROM listings WHERE id = ?').get(gone).n, 0, 'pending submission deleted');
  assert.equal(db.prepare('SELECT COUNT(*) n FROM audit_log WHERE actor_id = ?').get(u.id).n, 0);
  assert.equal(db.prepare("SELECT COUNT(*) n FROM audit_log WHERE action = 'user.deleted' AND target IS NULL").get().n, 1, 'deletion logged without identifier');
});

test('default deletion removes every submission of the user, even approved ones', () => {
  const db = fileDb(); const m = mod(db);
  const u = svc.createUser(db, 'me@example.org', PW);
  const id = svc.submitListing(db, u, { category: 'work', title: 'Approved job' });
  svc.moderateListing(db, m, id, { decision: 'approve' });
  accounts.deleteAccount(db, u.id, PW);
  assert.equal(db.prepare('SELECT COUNT(*) n FROM listings WHERE id = ?').get(id).n, 0);
});

// ---------- B. Saved items show names ----------
test('saved items return names and links for listings and official sources', () => {
  const db = fileDb(); seeded(db); const m = mod(db);
  const u = svc.createUser(db, 'me@example.org', PW);
  const id = svc.submitListing(db, u, { category: 'work', title: 'Offre test' });
  svc.moderateListing(db, m, id, { decision: 'approve' });
  svc.saveItem(db, u.id, 'listing', id);
  svc.saveItem(db, u.id, 'source', db.prepare("SELECT id FROM sources WHERE slug='actiris'").get().id);
  const items = svc.listSaved(db, u.id);
  assert.equal(items.length, 2);
  assert.ok(items.some((i) => i.name === 'Offre test'));
  assert.ok(items.some((i) => i.name === 'Actiris' && i.url === 'https://www.actiris.brussels/'));
});

// ---------- C. NOVA with the free test provider ----------
test('assistant works with the free mock provider without spend and without a price setup', async () => {
  const db = fileDb(); seeded(db);
  const cfg = load({ AI_ENABLED: 'true', AI_PROVIDER: 'mock' });
  const provider = createProvider(cfg);
  assert.equal(provider.name, 'mock');
  const out = await assistant.answer({ db, cfg, provider, message: 'I need work in Brussels' });
  assert.equal(out.status, 'ok');
  const { T, detectLang } = require('../src/ai/mockReplies');
  assert.ok(out.reply.startsWith(T[detectLang('I need work in Brussels')].tag), 'answer is labelled as test data');
  assert.ok(out.items.some((i) => i.name === 'Actiris'), 'answer is grounded in the database');
  assert.equal(db.prepare('SELECT COALESCE(SUM(cost_eur),0) s FROM ai_usage').get().s, 0, 'no cost recorded');
});

test('paid provider stays blocked without prices and limits even when enabled', async () => {
  const db = fileDb(); seeded(db);
  const cfg = load({ AI_ENABLED: 'true', AI_PROVIDER: 'anthropic', AI_API_KEY: 'k', AI_MODEL: 'm' });
  const out = await assistant.answer({ db, cfg, provider: createProvider(cfg), message: 'I need work' });
  assert.equal(out.status, 'unavailable');
  assert.equal(out.code, 'ai_prices_not_set');
});

// ---------- D. Brevo: ready, inert until approved ----------
test('Brevo does not send anything unless explicitly enabled (no network call made)', async () => {
  let calls = 0;
  const fake = async () => { calls++; return { ok: true }; };
  const cfg = load({ MAIL_PROVIDER: 'brevo', BREVO_API_KEY: 'k', MAIL_FROM: 'noreply@example.org' });
  const m = new BrevoMailer(cfg, fake);
  await assert.rejects(() => m.send({ to: 'a@b.co', subject: 's', text: 't' }), { code: 'mail_not_configured' });
  assert.equal(calls, 0);
});

test('Brevo payload is correct when enabled (verified with a stubbed transport, not the real service)', async () => {
  let seen = null;
  const fake = async (url, opts) => { seen = { url, opts, body: JSON.parse(opts.body) }; return { ok: true }; };
  const cfg = load({ MAIL_PROVIDER: 'brevo', BREVO_API_KEY: 'k', MAIL_FROM: 'noreply@example.org', MAIL_SEND_ENABLED: 'true' });
  await new BrevoMailer(cfg, fake).send({ to: 'a@b.co', subject: 'Reset', text: 'link' });
  assert.equal(seen.url, 'https://api.brevo.com/v3/smtp/email');
  assert.equal(seen.opts.headers['api-key'], 'k');
  assert.deepEqual(seen.body.to, [{ email: 'a@b.co' }]);
  assert.equal(seen.body.sender.email, 'noreply@example.org');
});

test('mail provider selection defaults to unconfigured and never to Brevo', () => {
  assert.equal(createMailer(load({})).constructor.name, 'UnconfiguredMailer');
  assert.equal(createMailer(load({ MAIL_PROVIDER: 'memory' })).constructor.name, 'MemoryMailer');
  assert.equal(createMailer(load({ MAIL_PROVIDER: 'brevo' })).constructor.name, 'BrevoMailer');
  assert.equal(load({ MAIL_PROVIDER: 'brevo' }).mailSendEnabled, false);
});
