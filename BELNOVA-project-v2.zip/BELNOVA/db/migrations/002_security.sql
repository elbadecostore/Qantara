-- Account recovery and email verification
ALTER TABLE users ADD COLUMN email_verified_at TEXT;
CREATE TABLE auth_tokens(
  id INTEGER PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  purpose TEXT NOT NULL CHECK(purpose IN ('verify_email','reset_password')),
  token_hash TEXT NOT NULL UNIQUE,
  expires_at TEXT NOT NULL,
  used_at TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX auth_tokens_user ON auth_tokens(user_id, purpose);
-- Anonymous/owned AI conversations are addressed by an unguessable token; only its hash is stored.
ALTER TABLE ai_conversations ADD COLUMN token_hash TEXT;
CREATE UNIQUE INDEX ai_conversations_token ON ai_conversations(token_hash);
-- Shared rate-limit store (works across processes once the app runs on several instances).
CREATE TABLE rate_limits(
  key TEXT PRIMARY KEY,
  count INTEGER NOT NULL,
  reset_at INTEGER NOT NULL
);
