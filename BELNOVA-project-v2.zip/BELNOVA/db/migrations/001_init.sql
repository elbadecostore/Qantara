CREATE TABLE users(
  id INTEGER PRIMARY KEY,
  email TEXT NOT NULL UNIQUE COLLATE NOCASE,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'user' CHECK(role IN ('user','moderator','admin')),
  disabled INTEGER NOT NULL DEFAULT 0 CHECK(disabled IN (0,1)),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE sessions(
  token_hash TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  expires_at TEXT NOT NULL
);
CREATE INDEX sessions_user ON sessions(user_id);
CREATE TABLE profiles(
  user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  skills TEXT NOT NULL DEFAULT '',
  years INTEGER CHECK(years IS NULL OR years BETWEEN 0 AND 60),
  languages TEXT NOT NULL DEFAULT '',
  employment TEXT CHECK(employment IS NULL OR employment IN ('f','p','a')),
  housing_budget_eur INTEGER CHECK(housing_budget_eur IS NULL OR housing_budget_eur BETWEEN 0 AND 100000),
  consent_at TEXT NOT NULL,
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE sources(
  id INTEGER PRIMARY KEY,
  slug TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  kind TEXT NOT NULL CHECK(kind IN ('public_body','nonprofit','commercial_portal')),
  region TEXT NOT NULL DEFAULT 'Brussels',
  official_url TEXT NOT NULL CHECK(official_url LIKE 'https://%'),
  access_method TEXT NOT NULL DEFAULT 'none' CHECK(access_method IN ('none','api','rss','partnership','manual_review')),
  permission_status TEXT NOT NULL DEFAULT 'none' CHECK(permission_status IN ('none','requested','granted','refused')),
  terms_checked_at TEXT,
  tags TEXT NOT NULL DEFAULT '',
  active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1)),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE source_categories(
  source_id INTEGER NOT NULL REFERENCES sources(id) ON DELETE CASCADE,
  category TEXT NOT NULL CHECK(category IN ('work','housing','food','support','services','community')),
  PRIMARY KEY(source_id, category)
);
CREATE TABLE listings(
  id INTEGER PRIMARY KEY,
  source_id INTEGER REFERENCES sources(id) ON DELETE SET NULL,
  submitted_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
  kind TEXT NOT NULL CHECK(kind IN ('external','community')),
  category TEXT NOT NULL CHECK(category IN ('work','housing','food','support','services','community')),
  title TEXT NOT NULL CHECK(length(title) BETWEEN 3 AND 200),
  summary TEXT NOT NULL DEFAULT '' CHECK(length(summary) <= 2000),
  city TEXT NOT NULL DEFAULT 'Brussels' CHECK(length(city) <= 100),
  url TEXT CHECK(url IS NULL OR url LIKE 'https://%'),
  tags TEXT NOT NULL DEFAULT '' CHECK(length(tags) <= 300),
  status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','approved','rejected','expired','reported')),
  verification TEXT NOT NULL DEFAULT 'none' CHECK(verification IN ('none','source_link_checked','verified')),
  last_checked_at TEXT,
  moderation_note TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX listings_public ON listings(status, category);
CREATE TABLE saved_items(
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  item_type TEXT NOT NULL CHECK(item_type IN ('listing','source')),
  item_id INTEGER NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY(user_id, item_type, item_id)
);
CREATE TABLE reports(
  id INTEGER PRIMARY KEY,
  listing_id INTEGER NOT NULL REFERENCES listings(id) ON DELETE CASCADE,
  reporter_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  reason TEXT NOT NULL CHECK(length(reason) BETWEEN 3 AND 500),
  status TEXT NOT NULL DEFAULT 'open' CHECK(status IN ('open','resolved')),
  resolved_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  resolved_at TEXT
);
CREATE TABLE ai_conversations(
  id INTEGER PRIMARY KEY,
  user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE ai_messages(
  id INTEGER PRIMARY KEY,
  conversation_id INTEGER NOT NULL REFERENCES ai_conversations(id) ON DELETE CASCADE,
  role TEXT NOT NULL CHECK(role IN ('user','assistant')),
  content TEXT NOT NULL CHECK(length(content) <= 4000),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE ai_usage(
  id INTEGER PRIMARY KEY,
  user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  provider TEXT NOT NULL,
  model TEXT NOT NULL,
  input_tokens INTEGER NOT NULL,
  output_tokens INTEGER NOT NULL,
  cost_eur REAL NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX ai_usage_created ON ai_usage(created_at);
CREATE TABLE audit_log(
  id INTEGER PRIMARY KEY,
  actor_id INTEGER,
  action TEXT NOT NULL,
  target TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE messages(
  id INTEGER PRIMARY KEY,
  sender_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  recipient_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  body TEXT NOT NULL CHECK(length(body) BETWEEN 1 AND 2000),
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  read_at TEXT
);
